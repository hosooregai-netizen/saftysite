'use client';

import type { MailAccount } from '@/types/mail';

const ALL_ACCOUNTS_FILTER = 'all';

type SyncTone = 'idle' | 'info' | 'success' | 'warning';

function formatDateTime(value: string | null | undefined) {
  if (!value) return '';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return new Intl.DateTimeFormat('ko-KR', {
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
  }).format(date);
}

function getMetadata(account: MailAccount | null) {
  return (account?.metadata ?? {}) as Record<string, unknown>;
}

function hasReconnectSignal(account: MailAccount | null) {
  const metadata = getMetadata(account);
  const text = String(metadata.syncError || account?.connectionStatus || '').toLowerCase();
  return Boolean(
    metadata.reconnectRequired ||
      text.includes('refresh token') ||
      text.includes('invalid_grant') ||
      text.includes('unauthorized') ||
      text.includes('재연결') ||
      text.includes('다시 연결'),
  );
}

function resolveTargetAccount(accounts: MailAccount[], selectedAccountId: string) {
  if (selectedAccountId && selectedAccountId !== ALL_ACCOUNTS_FILTER) {
    return accounts.find((account) => account.id === selectedAccountId) ?? null;
  }
  const googleAccount = accounts.find((account) => account.provider === 'google');
  return googleAccount ?? accounts[0] ?? null;
}

function resolveSyncState(account: MailAccount | null, syncing: boolean): {
  action: 'reconnect' | 'sync' | null;
  description: string;
  title: string;
  tone: SyncTone;
} | null {
  if (!account || account.provider !== 'google') return null;
  const metadata = getMetadata(account);
  const syncStatus = String(metadata.syncStatus || 'idle');
  const syncError = typeof metadata.syncError === 'string' ? metadata.syncError : '';
  const initialBackfillCompleted = Boolean(metadata.initialBackfillCompleted);
  const lastSyncedAt = account.lastSyncedAt || String(metadata.lastIncrementalSyncAt || metadata.lastFullSyncAt || '');

  if (hasReconnectSignal(account)) {
    return {
      action: 'reconnect',
      tone: 'warning',
      title: 'Gmail 재연결이 필요합니다.',
      description: syncError || 'Gmail refresh token을 사용할 수 없습니다. 구글 메일 계정을 다시 연결해 주세요.',
    };
  }

  if (syncing || syncStatus === 'backfilling' || syncStatus === 'incremental') {
    return {
      action: null,
      tone: 'info',
      title: syncStatus === 'incremental' ? 'Gmail 변경사항을 동기화하는 중입니다.' : 'Gmail 메일을 가져오는 중입니다.',
      description: '받은편지함과 보낸편지함을 최신 상태로 맞추고 있습니다. 잠시만 기다려 주세요.',
    };
  }

  if (syncError) {
    return {
      action: 'sync',
      tone: 'warning',
      title: 'Gmail 동기화에 실패했습니다.',
      description: syncError,
    };
  }

  if (!initialBackfillCompleted) {
    return {
      action: 'sync',
      tone: 'info',
      title: '초기 Gmail 동기화가 필요합니다.',
      description: '계정 연결은 완료되었습니다. 받은편지함과 보낸편지함을 가져오려면 동기화를 실행해 주세요.',
    };
  }

  if (lastSyncedAt) {
    return {
      action: 'sync',
      tone: 'success',
      title: 'Gmail 계정이 동기화되었습니다.',
      description: `마지막 동기화: ${formatDateTime(lastSyncedAt)}`,
    };
  }

  return {
    action: 'sync',
    tone: 'idle',
    title: 'Gmail 동기화 상태를 확인해 주세요.',
    description: '메일 목록이 비어 있다면 수동 동기화를 실행해 보세요.',
  };
}

export function MailboxSyncStatusBanner({
  accounts,
  onReconnect,
  onSync,
  selectedAccountId,
  syncing,
}: {
  accounts: MailAccount[];
  onReconnect: () => void;
  onSync: () => void;
  selectedAccountId: string;
  syncing: boolean;
}) {
  const account = resolveTargetAccount(accounts, selectedAccountId);
  const state = resolveSyncState(account, syncing);
  if (!state) return null;

  const background =
    state.tone === 'warning'
      ? '#fff7ed'
      : state.tone === 'success'
        ? '#f0fdf4'
        : state.tone === 'info'
          ? '#eff6ff'
          : '#f8fafc';
  const border =
    state.tone === 'warning'
      ? '#fed7aa'
      : state.tone === 'success'
        ? '#bbf7d0'
        : state.tone === 'info'
          ? '#bfdbfe'
          : '#e2e8f0';
  const color = state.tone === 'warning' ? '#9a3412' : state.tone === 'success' ? '#166534' : '#1e3a8a';

  return (
    <section
      aria-live="polite"
      style={{
        alignItems: 'center',
        background,
        border: `1px solid ${border}`,
        borderRadius: 16,
        color,
        display: 'flex',
        gap: 14,
        justifyContent: 'space-between',
        margin: '10px 16px',
        padding: '12px 14px',
      }}
    >
      <div style={{ display: 'grid', gap: 3 }}>
        <strong>{state.title}</strong>
        <span style={{ color: '#475569', fontSize: 13 }}>{state.description}</span>
      </div>
      {state.action === 'reconnect' ? (
        <button type="button" className="app-button app-button-primary" onClick={onReconnect}>
          구글 메일 재연결
        </button>
      ) : state.action === 'sync' ? (
        <button type="button" className="app-button app-button-secondary" onClick={onSync} disabled={syncing}>
          {syncing ? '동기화 중' : '지금 동기화'}
        </button>
      ) : null}
    </section>
  );
}

export default MailboxSyncStatusBanner;
