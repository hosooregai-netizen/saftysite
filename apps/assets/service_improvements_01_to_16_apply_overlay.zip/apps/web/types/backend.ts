export interface SafetyAssignedHeadquarterSummary {
  id: string;
  headquarter: {
    id: string;
    name: string;
    opening_number?: string;
    [key: string]: unknown;
  };
  site_count: number;
  [key: string]: unknown;
}

export interface SafetyUser {
  id: string;
  email: string;
  name: string;
  role?: string;
  is_active?: boolean;
  [key: string]: unknown;
}

export interface SafetySite {
  id: string;
  headquarter_id: string;
  site_name: string;
  client_business_name?: string;
  site_address?: string;
  manager_name?: string;
  last_visit_date?: string | null;
  status?: string;
  headquarter_detail?: {
    id: string;
    name: string;
    [key: string]: unknown;
  } | null;
  [key: string]: unknown;
}
