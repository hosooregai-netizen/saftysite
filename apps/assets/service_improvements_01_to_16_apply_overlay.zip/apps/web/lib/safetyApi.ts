'use client';

import type { SafetyAssignedHeadquarterSummary, SafetyUser } from '@/types/backend';
import { writeSafetyAuthToken, readSafetyAuthToken, clearSafetyAuthToken } from '@/lib/safetyApi/authStorage';

export { writeSafetyAuthToken, readSafetyAuthToken, clearSafetyAuthToken };

export class SafetyApiError extends Error {
  status: number;
  constructor(message: string, status = 500) {
    super(message);
    this.status = status;
  }
}

async function requestJson<T>(path: string, token?: string): Promise<T> {
  const response = await fetch(`/api/safety${path}`, {
    headers: token ? { authorization: `Bearer ${token}` } : {},
    cache: 'no-store',
  });
  const payload = await response.json().catch(() => null);
  if (!response.ok) throw new SafetyApiError(String(payload?.detail || payload?.error || 'Safety API 요청 실패'), response.status);
  return payload as T;
}

export function fetchCurrentSafetyUser(token?: string) {
  return requestJson<SafetyUser>('/users/me', token);
}

export function fetchAssignedSafetyHeadquarters(token?: string) {
  return requestJson<SafetyAssignedHeadquarterSummary[]>('/headquarters/assigned', token);
}
