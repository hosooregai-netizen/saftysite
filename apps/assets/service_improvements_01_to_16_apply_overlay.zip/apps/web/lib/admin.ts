export function getSiteStatusLabel(status: string | null | undefined) {
  if (status === 'active') return '진행 중';
  if (status === 'paused') return '중지';
  if (status === 'completed') return '완료';
  if (status === 'archived') return '보관';
  return status || '상태 미정';
}
