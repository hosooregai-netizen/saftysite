'use client';

const KEY = 'saftysite-safety-auth-token';

export function writeSafetyAuthToken(token: string) {
  if (typeof window !== 'undefined') window.localStorage.setItem(KEY, token);
}

export function readSafetyAuthToken() {
  if (typeof window === 'undefined') return '';
  return window.localStorage.getItem(KEY) || '';
}

export function clearSafetyAuthToken() {
  if (typeof window !== 'undefined') window.localStorage.removeItem(KEY);
}
