export interface GenerateInspectionDocumentRequest {
  reportId?: string;
  payload?: unknown;
  format?: 'pdf' | 'hwpx';
  [key: string]: unknown;
}
