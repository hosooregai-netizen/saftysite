export type SafetySiteStatus = 'active' | 'paused' | 'completed' | 'archived' | 'all' | string;

export interface SafetyHeadquarter {
  id: string;
  name: string;
  address?: string;
  opening_number?: string;
  business_registration_no?: string;
  corporate_registration_no?: string;
  contact_name?: string;
  contact_phone?: string;
  is_active?: boolean;
  license_no?: string;
  management_number?: string;
  memo?: string;
  [key: string]: unknown;
}

export interface SafetyHeadquarterInput {
  name: string;
  address?: string;
  opening_number?: string;
  business_registration_no?: string;
  corporate_registration_no?: string;
  contact_name?: string;
  contact_phone?: string;
  is_active?: boolean;
  license_no?: string;
  management_number?: string;
  memo?: string;
  [key: string]: unknown;
}

export type SafetyHeadquarterUpdateInput = Partial<SafetyHeadquarterInput>;

export interface SafetySiteInput {
  headquarter_id: string;
  site_name: string;
  client_business_name?: string;
  site_address?: string;
  manager_name?: string;
  status?: SafetySiteStatus;
  [key: string]: unknown;
}

export type SafetySiteUpdateInput = Partial<SafetySiteInput>;

export interface SafetyAssignment {
  id: string;
  user_id: string;
  site_id?: string;
  headquarter_id?: string;
  role?: string;
  is_active?: boolean;
  [key: string]: unknown;
}
