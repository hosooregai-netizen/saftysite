'use client';

import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { readSafetyAuthToken } from '@/lib/safetyApi/authStorage';
import type { PhotoAlbumItem, PhotoAlbumListResponse } from '@/types/photos';
import styles from './PhotoAlbumPanel.module.css';

export interface PhotoAlbumSiteOption {
  headquarterId?: string | null;
  headquarterName?: string | null;
  id: string;
  name?: string;
  siteName?: string;
  totalRounds?: number;
}

export interface PhotoAlbumListInput {
  deferredQuery: string;
  headquarterId: string;
  limit?: number;
  lockedHeadquarterId?: string;
  lockedSiteId?: string;
  offset?: number;
  roundNo?: string;
  siteId: string;
  sourceKind?: string;
}

export interface PhotoAlbumDataAdapter {
  deleteSelection?: (itemIds: string[]) => Promise<void>;
  downloadSelection?: (itemIds: string[]) => Promise<void>;
  list: (input: PhotoAlbumListInput) => Promise<PhotoAlbumListResponse>;
  updateRounds?: (itemIds: string[], nextRoundNo: number) => Promise<void>;
  upload?: (input: { capturedAt?: string; file: File; roundNo: number; siteId: string }) => Promise<PhotoAlbumItem>;
}

type ViewMode = 'grid' | 'list';

function formatDate(value: string | null | undefined) {
  if (!value) return '-';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value.slice(0, 10);
  return new Intl.DateTimeFormat('ko-KR', { dateStyle: 'medium' }).format(date);
}

function formatSize(value: number) {
  if (!Number.isFinite(value) || value <= 0) return '-';
  if (value < 1024) return `${value}B`;
  if (value < 1024 * 1024) return `${Math.round(value / 1024)}KB`;
  return `${(value / 1024 / 1024).toFixed(1)}MB`;
}

function siteLabel(site: PhotoAlbumSiteOption) {
  return site.siteName || site.name || site.id;
}

function createObjectUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ''));
    reader.onerror = () => reject(reader.error || new Error('파일을 읽지 못했습니다.'));
    reader.readAsDataURL(file);
  });
}

function normalizeServerItem(raw: any, sites: PhotoAlbumSiteOption[]): PhotoAlbumItem {
  const siteId = String(raw.siteId ?? raw.site_id ?? '');
  const headquarterId = String(raw.headquarterId ?? raw.headquarter_id ?? '');
  const matchedSite = sites.find((site) => site.id === siteId);
  return {
    capturedAt: String(raw.capturedAt ?? raw.captured_at ?? raw.createdAt ?? raw.created_at ?? ''),
    contentType: String(raw.contentType ?? raw.content_type ?? 'image/jpeg'),
    createdAt: String(raw.createdAt ?? raw.created_at ?? raw.capturedAt ?? raw.captured_at ?? ''),
    downloadUrl: String(raw.downloadUrl ?? raw.download_url ?? raw.dataUrl ?? raw.data_url ?? ''),
    fileName: String(raw.fileName ?? raw.file_name ?? 'photo.jpg'),
    gpsLatitude: raw.gpsLatitude ?? raw.gps_latitude ?? null,
    gpsLongitude: raw.gpsLongitude ?? raw.gps_longitude ?? null,
    headquarterId,
    headquarterName: String(raw.headquarterName ?? raw.headquarter_name ?? matchedSite?.headquarterName ?? '사업장 미상'),
    id: String(raw.id ?? raw._id ?? ''),
    previewUrl: String(raw.previewUrl ?? raw.preview_url ?? raw.dataUrl ?? raw.data_url ?? ''),
    roundNo: Number(raw.roundNo ?? raw.round_no ?? 1) || 1,
    siteId,
    siteName: String(raw.siteName ?? raw.site_name ?? matchedSite ? siteLabel(matchedSite!) : '현장 미상'),
    sizeBytes: Number(raw.sizeBytes ?? raw.size_bytes ?? 0) || 0,
    sourceDocumentKey: String(raw.sourceDocumentKey ?? raw.source_document_key ?? ''),
    sourceKind: String(raw.sourceKind ?? raw.source_kind ?? 'album_upload'),
    sourceReportKey: String(raw.sourceReportKey ?? raw.source_report_key ?? ''),
    sourceReportTitle: String(raw.sourceReportTitle ?? raw.source_report_title ?? ''),
    sourceSlotKey: String(raw.sourceSlotKey ?? raw.source_slot_key ?? ''),
    uploadedByName: String(raw.uploadedByName ?? raw.uploaded_by_name ?? ''),
    uploadedByUserId: String(raw.uploadedByUserId ?? raw.uploaded_by_user_id ?? ''),
  };
}

function getAuthHeaders() {
  const token = readSafetyAuthToken();
  return token ? { authorization: `Bearer ${token}` } : {};
}

function createServerAdapter(sites: PhotoAlbumSiteOption[]): PhotoAlbumDataAdapter {
  const baseUrl = '/api/report-saas/v1/photo-album';
  return {
    async deleteSelection(itemIds) {
      for (const itemId of itemIds) {
        const response = await fetch(`${baseUrl}/${encodeURIComponent(itemId)}`, {
          method: 'DELETE',
          headers: getAuthHeaders(),
        });
        if (!response.ok) throw new Error('사진을 삭제하지 못했습니다.');
      }
    },
    async downloadSelection() {
      // The UI downloads selected rows directly from their downloadUrl.
    },
    async list(input) {
      const params = new URLSearchParams();
      params.set('limit', String(input.limit ?? 40));
      params.set('offset', String(input.offset ?? 0));
      const nextHeadquarterId = input.lockedHeadquarterId || input.headquarterId;
      const nextSiteId = input.lockedSiteId || input.siteId;
      if (nextHeadquarterId) params.set('headquarter_id', nextHeadquarterId);
      if (nextSiteId) params.set('site_id', nextSiteId);
      if (input.deferredQuery) params.set('query', input.deferredQuery);
      const response = await fetch(`${baseUrl}?${params.toString()}`, {
        headers: getAuthHeaders(),
        cache: 'no-store',
      });
      const payload = await response.json().catch(() => null);
      if (!response.ok) throw new Error(String(payload?.detail || payload?.error || '사진첩을 불러오지 못했습니다.'));
      const rows = Array.isArray(payload?.rows) ? payload.rows.map((item: any) => normalizeServerItem(item, sites)) : [];
      return {
        capabilities: {
          deleteSupported: true,
          downloadSupported: true,
          roundUpdateSupported: true,
          uploadSupported: true,
        },
        limit: Number(payload?.limit ?? input.limit ?? 40),
        offset: Number(payload?.offset ?? input.offset ?? 0),
        rows,
        total: Number(payload?.total ?? rows.length),
      };
    },
    async updateRounds(itemIds, nextRoundNo) {
      for (const itemId of itemIds) {
        const response = await fetch(`${baseUrl}/${encodeURIComponent(itemId)}`, {
          method: 'PATCH',
          headers: { 'content-type': 'application/json', ...getAuthHeaders() },
          body: JSON.stringify({ round_no: nextRoundNo }),
        });
        if (!response.ok) throw new Error('회차를 저장하지 못했습니다.');
      }
    },
    async upload(input) {
      const dataUrl = await createObjectUrl(input.file);
      const matchedSite = sites.find((site) => site.id === input.siteId);
      const response = await fetch(baseUrl, {
        method: 'POST',
        headers: { 'content-type': 'application/json', ...getAuthHeaders() },
        body: JSON.stringify({
          captured_at: input.capturedAt || new Date().toISOString(),
          content_type: input.file.type || 'image/jpeg',
          data_url: dataUrl,
          file_name: input.file.name,
          headquarter_id: matchedSite?.headquarterId || '',
          local_id: '',
          round_no: input.roundNo,
          site_id: input.siteId,
          size_bytes: input.file.size,
          source_kind: 'album_upload',
        }),
      });
      const payload = await response.json().catch(() => null);
      if (!response.ok) throw new Error(String(payload?.detail || payload?.error || '사진을 업로드하지 못했습니다.'));
      return normalizeServerItem(payload, sites);
    },
  };
}

export function PhotoAlbumPanel({
  capabilityNotice,
  dataAdapter,
  initialHeadquarterId,
  initialSiteId,
  mode = 'admin',
  sites = [],
}: {
  capabilityNotice?: string | null;
  dataAdapter?: PhotoAlbumDataAdapter;
  initialHeadquarterId?: string | null;
  initialSiteId?: string | null;
  mode?: 'admin' | 'viewer' | string;
  sites?: PhotoAlbumSiteOption[];
}) {
  const uploadInputRef = useRef<HTMLInputElement | null>(null);
  const [headquarterId, setHeadquarterId] = useState(initialHeadquarterId || '');
  const [siteId, setSiteId] = useState(initialSiteId || '');
  const [roundNo, setRoundNo] = useState('');
  const [query, setQuery] = useState('');
  const [sourceKind, setSourceKind] = useState('');
  const [viewMode, setViewMode] = useState<ViewMode>('grid');
  const [rows, setRows] = useState<PhotoAlbumItem[]>([]);
  const [total, setTotal] = useState(0);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [activeItem, setActiveItem] = useState<PhotoAlbumItem | null>(null);
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');

  const adapter = useMemo(() => dataAdapter ?? createServerAdapter(sites), [dataAdapter, sites]);
  const selectedRows = useMemo(() => rows.filter((row) => selectedIds.has(row.id)), [rows, selectedIds]);
  const uniqueHeadquarters = useMemo(() => {
    const map = new Map<string, string>();
    sites.forEach((site) => {
      if (site.headquarterId) map.set(site.headquarterId, site.headquarterName || '사업장 미상');
    });
    return Array.from(map, ([id, name]) => ({ id, name })).sort((a, b) => a.name.localeCompare(b.name, 'ko'));
  }, [sites]);
  const filteredSites = useMemo(() => sites.filter((site) => !headquarterId || site.headquarterId === headquarterId), [headquarterId, sites]);
  const capabilities = useMemo(() => ({
    deleteSupported: true,
    downloadSupported: true,
    roundUpdateSupported: true,
    uploadSupported: true,
  }), []);

  const loadRows = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const response = await adapter.list({
        deferredQuery: query.trim().toLowerCase(),
        headquarterId,
        limit: 80,
        lockedHeadquarterId: '',
        lockedSiteId: '',
        offset: 0,
        roundNo,
        siteId,
        sourceKind,
      });
      let nextRows = response.rows;
      if (roundNo) nextRows = nextRows.filter((row) => String(row.roundNo) === roundNo);
      if (sourceKind) nextRows = nextRows.filter((row) => row.sourceKind === sourceKind);
      setRows(nextRows);
      setTotal(response.total ?? nextRows.length);
      setSelectedIds(new Set());
    } catch (nextError) {
      setError(nextError instanceof Error ? nextError.message : '사진첩을 불러오지 못했습니다.');
    } finally {
      setLoading(false);
    }
  }, [adapter, headquarterId, query, roundNo, siteId, sourceKind]);

  useEffect(() => {
    void loadRows();
  }, [loadRows]);

  const handleHeadquarterChange = (value: string) => {
    setHeadquarterId(value);
    const selectedSite = sites.find((site) => site.id === siteId);
    if (selectedSite && value && selectedSite.headquarterId !== value) {
      setSiteId('');
    }
  };

  const handleSiteChange = (value: string) => {
    setSiteId(value);
    const nextSite = sites.find((site) => site.id === value);
    if (nextSite?.headquarterId) setHeadquarterId(nextSite.headquarterId);
  };

  const toggleSelected = (itemId: string) => {
    setSelectedIds((current) => {
      const next = new Set(current);
      if (next.has(itemId)) next.delete(itemId);
      else next.add(itemId);
      return next;
    });
  };

  const handleUpload = async (files: FileList | null) => {
    if (!files?.length) return;
    if (!siteId) {
      setError('사진을 업로드할 현장을 먼저 선택해 주세요.');
      return;
    }
    if (!adapter.upload) {
      setError('현재 모드에서는 사진 업로드를 사용할 수 없습니다.');
      return;
    }
    setUploading(true);
    setError('');
    try {
      const nextRoundNo = Number(roundNo || 1) || 1;
      for (const file of Array.from(files)) {
        if (!file.type.startsWith('image/')) {
          throw new Error('이미지 파일만 업로드할 수 있습니다.');
        }
        await adapter.upload({ file, roundNo: nextRoundNo, siteId });
      }
      setNotice(`${files.length}개 사진을 업로드했습니다.`);
      await loadRows();
    } catch (nextError) {
      setError(nextError instanceof Error ? nextError.message : '사진을 업로드하지 못했습니다.');
    } finally {
      setUploading(false);
      if (uploadInputRef.current) uploadInputRef.current.value = '';
    }
  };

  const handleDownloadSelected = async () => {
    if (selectedRows.length === 0) return;
    if (adapter.downloadSelection) {
      await adapter.downloadSelection(selectedRows.map((row) => row.id));
      return;
    }
    selectedRows.forEach((row) => window.open(row.downloadUrl, '_blank', 'noopener,noreferrer'));
  };

  const handleDeleteSelected = async () => {
    if (selectedRows.length === 0 || !adapter.deleteSelection) return;
    if (!window.confirm(`${selectedRows.length}개 사진을 삭제할까요?`)) return;
    await adapter.deleteSelection(selectedRows.map((row) => row.id));
    setNotice('선택한 사진을 삭제했습니다.');
    await loadRows();
  };

  const handleUpdateRound = async () => {
    if (selectedRows.length === 0 || !adapter.updateRounds) return;
    const value = window.prompt('변경할 지도 회차를 입력하세요.', roundNo || '1');
    if (!value) return;
    const nextRoundNo = Number(value);
    if (!Number.isFinite(nextRoundNo) || nextRoundNo <= 0) {
      setError('회차는 1 이상의 숫자로 입력해 주세요.');
      return;
    }
    await adapter.updateRounds(selectedRows.map((row) => row.id), nextRoundNo);
    setNotice('선택한 사진의 회차를 변경했습니다.');
    await loadRows();
  };

  const emptyMessage = query || headquarterId || siteId || roundNo || sourceKind
    ? '조건에 맞는 사진이 없습니다. 필터를 초기화하거나 다른 현장을 선택해 주세요.'
    : '아직 등록된 사진이 없습니다. 현장 사진을 업로드해 사진첩을 시작해 주세요.';

  return (
    <section className={styles.panel}>
      <header className={styles.headerCard}>
        <div>
          <span className={styles.kicker}>Photo Album</span>
          <h1 className={styles.title}>사진첩</h1>
          <p className={styles.meta}>현장 사진을 사업장, 현장, 회차 기준으로 보관하고 보고서 증거 자료로 연결합니다.</p>
        </div>
        <div className={styles.summaryLine}>{mode === 'admin' ? '관리 모드' : '보기 모드'} · {total}개 사진</div>
      </header>

      {capabilityNotice ? <div className={styles.notice}>{capabilityNotice}</div> : null}
      {error ? <div className={styles.notice} role="alert">{error}</div> : null}
      {notice ? <div className={styles.notice}>{notice}</div> : null}

      <div className={styles.toolbar}>
        <div className={styles.filters}>
          <label className={styles.field}>
            <span>사업장</span>
            <select className={styles.select} value={headquarterId} onChange={(event) => handleHeadquarterChange(event.target.value)}>
              <option value="">전체 사업장</option>
              {uniqueHeadquarters.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}
            </select>
          </label>
          <label className={styles.field}>
            <span>현장</span>
            <select className={styles.select} value={siteId} onChange={(event) => handleSiteChange(event.target.value)}>
              <option value="">전체 현장</option>
              {filteredSites.map((site) => <option key={site.id} value={site.id}>{siteLabel(site)}</option>)}
            </select>
          </label>
          <label className={styles.field}>
            <span>회차</span>
            <input className={styles.input} value={roundNo} inputMode="numeric" placeholder="전체" onChange={(event) => setRoundNo(event.target.value.replace(/[^0-9]/g, ''))} />
          </label>
          <label className={styles.field}>
            <span>출처</span>
            <select className={styles.select} value={sourceKind} onChange={(event) => setSourceKind(event.target.value)}>
              <option value="">전체 출처</option>
              <option value="album_upload">사진첩 업로드</option>
              <option value="report_photo">보고서 사진</option>
              <option value="manual">수동 등록</option>
            </select>
          </label>
          <label className={styles.field}>
            <span>검색</span>
            <input className={styles.input} value={query} placeholder="파일명, 현장명 검색" onChange={(event) => setQuery(event.target.value)} />
          </label>
        </div>

        <div className={styles.toolbarActions}>
          <div className={styles.segment} aria-label="보기 전환">
            <button type="button" className={viewMode === 'grid' ? styles.active : ''} onClick={() => setViewMode('grid')}>Grid</button>
            <button type="button" className={viewMode === 'list' ? styles.active : ''} onClick={() => setViewMode('list')}>List</button>
          </div>
          <div className={styles.summaryLine}>선택 {selectedRows.length}개 · 표시 {rows.length}개</div>
          <div className={styles.toolbarActions}>
            <button type="button" className={styles.secondaryButton} onClick={() => void loadRows()} disabled={loading}>새로고침</button>
            <button type="button" className={styles.button} onClick={() => uploadInputRef.current?.click()} disabled={uploading || !siteId || !adapter.upload}>사진 업로드</button>
            <input ref={uploadInputRef} className={styles.uploadInput} type="file" accept="image/*" multiple onChange={(event) => void handleUpload(event.currentTarget.files)} />
            <button type="button" className={styles.secondaryButton} onClick={() => void handleDownloadSelected()} disabled={selectedRows.length === 0}>다운로드</button>
            <button type="button" className={styles.secondaryButton} onClick={() => void handleUpdateRound()} disabled={selectedRows.length === 0 || !adapter.updateRounds}>회차 변경</button>
            <button type="button" className={styles.dangerButton} onClick={() => void handleDeleteSelected()} disabled={selectedRows.length === 0 || !adapter.deleteSelection}>삭제</button>
          </div>
        </div>
      </div>

      {loading ? <div className={styles.empty}>사진을 불러오는 중입니다.</div> : rows.length === 0 ? (
        <div className={styles.empty}>
          <strong>표시할 사진이 없습니다.</strong>
          <p>{emptyMessage}</p>
        </div>
      ) : viewMode === 'grid' ? (
        <div className={styles.grid}>
          {rows.map((item) => (
            <article key={item.id} className={`${styles.card} ${selectedIds.has(item.id) ? styles.cardSelected : ''}`}>
              <button type="button" className={styles.thumbButton} onClick={() => setActiveItem(item)}>
                <div className={styles.thumb}>{item.previewUrl ? <img src={item.previewUrl} alt={item.fileName} /> : <span>미리보기 없음</span>}</div>
              </button>
              <div className={styles.cardBody}>
                <label className={styles.badges}>
                  <input type="checkbox" checked={selectedIds.has(item.id)} onChange={() => toggleSelected(item.id)} />
                  <span className={styles.fileName}>{item.fileName}</span>
                </label>
                <div className={styles.badges}>
                  <span className={styles.badge}>{item.roundNo}회차</span>
                  <span className={styles.badgeMuted}>{item.sourceKind === 'report_photo' ? '보고서 사진' : '사진첩'}</span>
                  {item.sourceReportKey ? <span className={styles.badge}>보고서 연결</span> : <span className={styles.badgeMuted}>미연결</span>}
                </div>
                <div className={styles.cardMeta}>
                  <span>{item.headquarterName}</span>
                  <span>{item.siteName}</span>
                  <span>{formatDate(item.capturedAt || item.createdAt)} · {formatSize(item.sizeBytes)}</span>
                </div>
              </div>
            </article>
          ))}
        </div>
      ) : (
        <div className={styles.tableWrap}>
          <table className={styles.table}>
            <thead>
              <tr>
                <th>선택</th>
                <th>파일명</th>
                <th>사업장/현장</th>
                <th>회차</th>
                <th>촬영일</th>
                <th>출처</th>
                <th>작업</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((item) => (
                <tr key={item.id} className={styles.tableRow} onClick={() => setActiveItem(item)}>
                  <td onClick={(event) => event.stopPropagation()}><input type="checkbox" checked={selectedIds.has(item.id)} onChange={() => toggleSelected(item.id)} /></td>
                  <td>{item.fileName}</td>
                  <td>{item.headquarterName}<br /><span className={styles.meta}>{item.siteName}</span></td>
                  <td>{item.roundNo}회차</td>
                  <td>{formatDate(item.capturedAt || item.createdAt)}</td>
                  <td>{item.sourceKind === 'report_photo' ? '보고서 사진' : '사진첩'}</td>
                  <td><button type="button" className={styles.secondaryButton} onClick={(event) => { event.stopPropagation(); setActiveItem(item); }}>상세</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {activeItem ? (
        <div className={styles.drawerBackdrop} role="presentation" onClick={() => setActiveItem(null)}>
          <aside className={styles.drawer} role="dialog" aria-label="사진 상세" onClick={(event) => event.stopPropagation()}>
            <header className={styles.drawerHeader}>
              <div>
                <h2>{activeItem.fileName}</h2>
                <p className={styles.meta}>{activeItem.siteName} · {activeItem.roundNo}회차</p>
              </div>
              <button type="button" className={styles.secondaryButton} onClick={() => setActiveItem(null)}>닫기</button>
            </header>
            <div className={styles.drawerBody}>
              <div className={styles.previewLarge}>{activeItem.previewUrl ? <img src={activeItem.previewUrl} alt={activeItem.fileName} /> : <span>미리보기 없음</span>}</div>
              <div className={styles.detailGrid}>
                <div className={styles.detailItem}><span>사업장</span><strong>{activeItem.headquarterName}</strong></div>
                <div className={styles.detailItem}><span>현장</span><strong>{activeItem.siteName}</strong></div>
                <div className={styles.detailItem}><span>회차</span><strong>{activeItem.roundNo}회차</strong></div>
                <div className={styles.detailItem}><span>촬영일</span><strong>{formatDate(activeItem.capturedAt)}</strong></div>
                <div className={styles.detailItem}><span>용량</span><strong>{formatSize(activeItem.sizeBytes)}</strong></div>
                <div className={styles.detailItem}><span>업로드</span><strong>{activeItem.uploadedByName || '-'}</strong></div>
                <div className={styles.detailItem}><span>보고서 연결</span><strong>{activeItem.sourceReportKey ? activeItem.sourceReportTitle || activeItem.sourceReportKey : '미연결'}</strong></div>
                <div className={styles.detailItem}><span>출처</span><strong>{activeItem.sourceKind}</strong></div>
              </div>
            </div>
            <footer className={styles.drawerActions}>
              <button type="button" className={styles.secondaryButton} onClick={() => window.open(activeItem.downloadUrl, '_blank', 'noopener,noreferrer')}>다운로드</button>
              {activeItem.sourceReportKey ? (
                <a className={styles.secondaryButton} href={`/reports/${encodeURIComponent(activeItem.sourceReportKey)}`}>보고서에서 열기</a>
              ) : (
                <button type="button" className={styles.secondaryButton} onClick={() => setNotice('보고서 연결 기능은 다음 단계에서 연결됩니다.')}>보고서에 연결</button>
              )}
            </footer>
          </aside>
        </div>
      ) : null}
    </section>
  );
}

export default PhotoAlbumPanel;
