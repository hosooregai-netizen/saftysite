'use client';

import type { SafetySite, SafetyUser } from '@/types/backend';
import type {
  SafetyAssignment,
  SafetyHeadquarter,
  SafetyHeadquarterInput,
  SafetyHeadquarterUpdateInput,
  SafetySiteInput,
  SafetySiteUpdateInput,
} from '@/types/controller';

async function requestJson<T>(path: string, init: RequestInit = {}): Promise<T> {
  const response = await fetch(path, {
    ...init,
    headers: {
      ...(init.body ? { 'content-type': 'application/json' } : {}),
      ...(init.headers || {}),
    },
    cache: 'no-store',
  });
  const payload = await response.json().catch(() => null);
  if (!response.ok) throw new Error(String(payload?.detail || payload?.error || '관리 API 요청 실패'));
  return payload as T;
}

function authHeaders(token?: string) {
  return token ? { authorization: `Bearer ${token}` } : {};
}

export async function fetchSafetyHeadquarters(token?: string): Promise<SafetyHeadquarter[]> {
  const response = await requestJson<{ rows?: SafetyHeadquarter[] } | SafetyHeadquarter[]>('/api/admin/headquarters/list?limit=500', { headers: authHeaders(token) });
  return Array.isArray(response) ? response : response.rows || [];
}

export async function fetchSafetySitesAdmin(tokenOrInput?: string | Record<string, unknown>): Promise<SafetySite[]> {
  const token = typeof tokenOrInput === 'string' ? tokenOrInput : undefined;
  const response = await requestJson<{ rows?: SafetySite[] } | SafetySite[]>('/api/admin/sites/list?limit=500', { headers: authHeaders(token) });
  return Array.isArray(response) ? response : response.rows || [];
}

export async function createSafetyHeadquarter(token: string, input: SafetyHeadquarterInput) {
  return requestJson<SafetyHeadquarter>('/api/admin/headquarters', {
    method: 'POST',
    headers: authHeaders(token),
    body: JSON.stringify(input),
  });
}

export async function updateSafetyHeadquarter(token: string, id: string, input: SafetyHeadquarterUpdateInput) {
  return requestJson<SafetyHeadquarter>(`/api/admin/headquarters/${encodeURIComponent(id)}`, {
    method: 'PATCH',
    headers: authHeaders(token),
    body: JSON.stringify(input),
  });
}

export async function deleteSafetyHeadquarter(token: string, id: string) {
  return requestJson<{ ok?: boolean }>(`/api/admin/headquarters/${encodeURIComponent(id)}`, {
    method: 'DELETE',
    headers: authHeaders(token),
  });
}

export async function createSafetySite(token: string, input: SafetySiteInput) {
  return requestJson<SafetySite>('/api/admin/sites', {
    method: 'POST',
    headers: authHeaders(token),
    body: JSON.stringify(input),
  });
}

export async function updateSafetySite(token: string, id: string, input: SafetySiteUpdateInput) {
  return requestJson<SafetySite>(`/api/admin/sites/${encodeURIComponent(id)}`, {
    method: 'PATCH',
    headers: authHeaders(token),
    body: JSON.stringify(input),
  });
}

export async function deleteSafetySite(token: string, id: string) {
  return requestJson<{ ok?: boolean }>(`/api/admin/sites/${encodeURIComponent(id)}`, {
    method: 'DELETE',
    headers: authHeaders(token),
  });
}

export const deactivateSafetySite = deleteSafetySite;
export const deactivateSafetyHeadquarter = deleteSafetyHeadquarter;

export function fetchSafetyUsers(token?: string) {
  return requestJson<{ rows?: SafetyUser[] } | SafetyUser[]>('/api/admin/users?limit=500', { headers: authHeaders(token) });
}

export function fetchSafetyAssignmentsPage() {
  return requestJson<{ rows: SafetyAssignment[]; total: number }>('/api/admin/assignments?limit=500');
}

export function createSafetyAssignment(token: string, input: Partial<SafetyAssignment>) {
  return requestJson<SafetyAssignment>('/api/admin/assignments', {
    method: 'POST',
    headers: authHeaders(token),
    body: JSON.stringify(input),
  });
}

export function updateSafetyAssignment(token: string, id: string, input: Partial<SafetyAssignment>) {
  return requestJson<SafetyAssignment>(`/api/admin/assignments/${encodeURIComponent(id)}`, {
    method: 'PATCH',
    headers: authHeaders(token),
    body: JSON.stringify(input),
  });
}

export function deactivateSafetyAssignment(token: string, id: string) {
  return requestJson<{ ok?: boolean }>(`/api/admin/assignments/${encodeURIComponent(id)}`, {
    method: 'DELETE',
    headers: authHeaders(token),
  });
}
