'use client';

export type GuidedChecklistStepId = 'meta' | 'overview' | 'hazard';
export type GuidedChecklistStatus = 'active' | 'blocked' | 'complete' | 'pending';

export interface GuidedChecklistItem {
  countLabel?: string;
  description: string;
  id: string;
  label: string;
  status: GuidedChecklistStatus;
  step: GuidedChecklistStepId;
}

function statusLabel(status: GuidedChecklistStatus) {
  if (status === 'complete') return '완료';
  if (status === 'active') return '진행 중';
  if (status === 'blocked') return '대기';
  return '필요';
}

function statusStyles(status: GuidedChecklistStatus): { background: string; border: string; color: string } {
  if (status === 'complete') {
    return { background: '#e8f5ee', border: '#b9e0c8', color: '#137333' };
  }
  if (status === 'active') {
    return { background: '#edf4ff', border: '#c7d8fb', color: '#0b57d0' };
  }
  if (status === 'blocked') {
    return { background: '#f8f9fa', border: '#e0e3e7', color: '#5f6368' };
  }
  return { background: '#fff8e6', border: '#f2d28a', color: '#8a5a00' };
}

export function ReportGuidedUploadChecklist({
  activeStep,
  isGenerating,
  items,
  onSelectStep,
  optionalPhotoCount,
}: {
  activeStep: GuidedChecklistStepId;
  isGenerating: boolean;
  items: GuidedChecklistItem[];
  onSelectStep: (step: GuidedChecklistStepId) => void;
  optionalPhotoCount: number;
}) {
  const completedCount = items.filter((item) => item.status === 'complete').length;
  const ready = completedCount === items.length;

  return (
    <section
      aria-label="보고서 생성 준비 체크리스트"
      style={{
        background: '#fff',
        border: '1px solid #e0e3e7',
        borderRadius: 18,
        boxShadow: '0 10px 30px rgba(60, 64, 67, 0.07)',
        display: 'grid',
        gap: 14,
        padding: 18,
      }}
    >
      <div style={{ alignItems: 'start', display: 'flex', gap: 16, justifyContent: 'space-between' }}>
        <div>
          <span style={{ color: '#0b57d0', fontSize: 12, fontWeight: 800, letterSpacing: '.04em', textTransform: 'uppercase' }}>
            Generation readiness
          </span>
          <h2 style={{ fontSize: 18, margin: '4px 0' }}>AI 초안 생성 준비 상태</h2>
          <p style={{ color: '#5f6368', fontSize: 13, margin: 0 }}>
            기본정보와 필수 사진 2장을 모두 준비해야 초안을 생성할 수 있습니다.
          </p>
        </div>
        <span
          style={{
            background: ready ? '#e8f5ee' : '#fff8e6',
            border: `1px solid ${ready ? '#b9e0c8' : '#f2d28a'}`,
            borderRadius: 999,
            color: ready ? '#137333' : '#8a5a00',
            fontSize: 12,
            fontWeight: 800,
            padding: '7px 10px',
            whiteSpace: 'nowrap',
          }}
        >
          {isGenerating ? '초안 생성 중' : ready ? '생성 가능' : `${completedCount}/${items.length} 완료`}
        </span>
      </div>

      <div style={{ display: 'grid', gap: 10, gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))' }}>
        {items.map((item) => {
          const tone = statusStyles(item.status);
          const active = activeStep === item.step;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => onSelectStep(item.step)}
              style={{
                background: active ? '#f8fbff' : '#fff',
                border: `1px solid ${active ? '#8ab4f8' : '#e0e3e7'}`,
                borderRadius: 16,
                cursor: 'pointer',
                display: 'grid',
                gap: 8,
                padding: 14,
                textAlign: 'left',
              }}
            >
              <div style={{ alignItems: 'center', display: 'flex', justifyContent: 'space-between', gap: 8 }}>
                <strong style={{ fontSize: 14 }}>{item.label}</strong>
                <span
                  style={{
                    background: tone.background,
                    border: `1px solid ${tone.border}`,
                    borderRadius: 999,
                    color: tone.color,
                    fontSize: 11,
                    fontWeight: 800,
                    padding: '4px 8px',
                    whiteSpace: 'nowrap',
                  }}
                >
                  {item.countLabel ? `${item.countLabel} · ` : ''}{statusLabel(item.status)}
                </span>
              </div>
              <span style={{ color: '#5f6368', fontSize: 12, lineHeight: 1.5 }}>{item.description}</span>
            </button>
          );
        })}
      </div>

      <div
        style={{
          alignItems: 'center',
          background: '#f8fafd',
          border: '1px dashed #d2d7e0',
          borderRadius: 14,
          color: '#5f6368',
          display: 'flex',
          flexWrap: 'wrap',
          fontSize: 12,
          gap: 10,
          justifyContent: 'space-between',
          padding: '10px 12px',
        }}
      >
        <span>선택 사진 {optionalPhotoCount}장 · 이전 지적사항, 교육, 추가 전경 사진은 검토 품질을 높이는 데 사용됩니다.</span>
        <span>{ready ? '생성 버튼을 누르면 사진 업로드 후 AI 초안을 작성합니다.' : '필수 항목을 완료하면 생성 버튼이 활성화됩니다.'}</span>
      </div>
    </section>
  );
}

export default ReportGuidedUploadChecklist;
