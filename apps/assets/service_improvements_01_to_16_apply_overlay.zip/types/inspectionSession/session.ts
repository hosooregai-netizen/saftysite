export interface InspectionSession {
  id: string;
  workspaceId?: string;
  currentSection: string;
  createdAt: string;
  updatedAt: string;
  meta: Record<string, any>;
  adminSiteSnapshot: Record<string, any>;
  technicalGuidanceRelations: Record<string, any>;
  document2Overview: Record<string, any>;
  document3Scenes: any[];
  document7Findings: any[];
  document8FutureProcesses: any[];
  document11SafetyEducations: any[];
  document12Activities: any[];
  document4FollowUps: any[];
  [key: string]: any;
}
