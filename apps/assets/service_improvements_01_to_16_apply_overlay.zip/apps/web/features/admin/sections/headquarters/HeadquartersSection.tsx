'use client';

import Link from 'next/link';
import styles from '@/features/admin/sections/AdminSectionShared.module.css';

export function HeadquartersSection(props: any) {
  const headquarters = props.headquarters || [];
  const sites = props.sites || [];
  const selectedHeadquarter = headquarters.find((item: any) => item.id === props.selectedHeadquarterId) || null;
  const selectedSites = selectedHeadquarter ? sites.filter((site: any) => site.headquarter_id === selectedHeadquarter.id) : sites;
  return (
    <section className={styles.directoryPanel}>
      <header className={styles.panelHeader}>
        <div><h2 className={styles.panelTitle}>사업장/현장 디렉터리</h2><p className={styles.panelHint}>보고서, 사진첩, 메일함의 기준 데이터를 한곳에서 관리합니다.</p></div>
        <div className={styles.toolbar}><button type="button" className={styles.secondaryButton} onClick={props.onClearHeadquarterSelection}>전체 사업장</button></div>
      </header>
      <div className={styles.summaryGrid} style={{ padding: 16 }}>
        <div className={styles.summaryCard}><div className={styles.summaryValue}>{headquarters.length}</div><div className={styles.summaryLabel}>사업장</div></div>
        <div className={styles.summaryCard}><div className={styles.summaryValue}>{sites.length}</div><div className={styles.summaryLabel}>현장</div></div>
        <div className={styles.summaryCard}><div className={styles.summaryValue}>{selectedSites.length}</div><div className={styles.summaryLabel}>선택 범위 현장</div></div>
      </div>
      {selectedHeadquarter ? <div className={styles.filterBar}><Link className={styles.secondaryButton} href={props.buildHeadquarterPhotoAlbumHref?.(selectedHeadquarter.id) || '/photo-album'}>사업장 사진첩</Link><Link className={styles.secondaryButton} href={props.buildHeadquartersHref?.({ headquarterId: selectedHeadquarter.id }) || '/headquarters'}>링크 복사</Link></div> : null}
    </section>
  );
}
