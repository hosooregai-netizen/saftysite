export function createActivityRecord(input: any = {}) { return { id: `activity-${Date.now()}-${Math.random()}`, ...input }; }
export function createCurrentHazardFinding(input: any = {}) { return { id: `finding-${Date.now()}-${Math.random()}`, ...input }; }
export function createFutureProcessRiskPlan(input: any = {}) { return { id: `future-${Date.now()}-${Math.random()}`, ...input }; }
export function createPreviousGuidanceFollowUpItem(input: any = {}) { return { id: `followup-${Date.now()}-${Math.random()}`, ...input }; }
export function createSafetyEducationRecord(input: any = {}) { return { id: `education-${Date.now()}-${Math.random()}`, ...input }; }
export function padDocument12Activities(rows: any[] = []) { return rows.length ? rows : [createActivityRecord()]; }
