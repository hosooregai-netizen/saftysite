export interface PhotoAlbumItem {
  id: string;
  siteId: string;
  siteName: string;
  headquarterId: string;
  headquarterName: string;
  roundNo: number;
  capturedAt: string;
  createdAt: string;
  fileName: string;
  contentType: string;
  sizeBytes: number;
  previewUrl: string;
  downloadUrl: string;
  sourceKind: string;
  sourceDocumentKey?: string;
  sourceReportKey?: string;
  sourceReportTitle?: string;
  sourceSlotKey?: string;
  uploadedByName?: string;
  uploadedByUserId?: string;
  gpsLatitude?: number | null;
  gpsLongitude?: number | null;
}

export interface PhotoAlbumListCapabilities {
  deleteSupported?: boolean;
  downloadSupported?: boolean;
  evidenceLinkingSupported?: boolean;
  roundUpdateSupported?: boolean;
  uploadSupported?: boolean;
}

export interface PhotoAlbumListResponse {
  capabilities?: PhotoAlbumListCapabilities;
  limit: number;
  offset: number;
  rows: PhotoAlbumItem[];
  total: number;
}
