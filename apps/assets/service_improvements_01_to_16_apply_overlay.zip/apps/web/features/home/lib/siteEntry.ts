import type { SafetySite } from '@/types/backend';

function withSite(path: string, site: SafetySite) {
  const params = new URLSearchParams();
  params.set('siteId', site.id);
  if (site.headquarter_id) params.set('headquarterId', site.headquarter_id);
  return `${path}?${params.toString()}`;
}

export function buildSiteHubHref(site: SafetySite) {
  return withSite('/sites', site);
}

export function buildSiteReportsHref(site: SafetySite) {
  return withSite('/reports', site);
}

export function buildSiteQuarterlyListHref(site: SafetySite, month?: string) {
  const base = withSite('/reports', site);
  return month ? `${base}&month=${encodeURIComponent(month)}` : base;
}

export function buildSiteBadWorkplaceHref(site: SafetySite) {
  return withSite('/reports/new', site);
}
