import type { MailMessage, MailRecipient, MailThread, MailThreadDetail } from '@/types/mail';

export function isLikelyEmail(value: string) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value.trim());
}

export function dedupeRecipients(values: string[]) {
  const seen = new Set<string>();
  return values
    .map((value) => value.trim())
    .filter(Boolean)
    .filter((value) => {
      const key = value.toLowerCase();
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
}

export function stripHtmlToText(value: string) {
  return value
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<[^>]*>/g, ' ')
    .replace(/&nbsp;/g, ' ')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&amp;/g, '&')
    .replace(/\s+/g, ' ')
    .trim();
}

export function buildReplySubject(subject: string) {
  const normalized = subject.trim();
  return /^re:/i.test(normalized) ? normalized : `Re: ${normalized || '(제목 없음)'}`;
}

export function buildForwardSubject(subject: string) {
  const normalized = subject.trim();
  return /^(fw|fwd):/i.test(normalized) ? normalized : `Fw: ${normalized || '(제목 없음)'}`;
}

function messageBody(message: Partial<MailMessage> | null | undefined) {
  return message?.bodyHtml || message?.body || message?.bodyText || '';
}

export function buildForwardBody(input: MailThreadDetail | MailMessage | null | undefined) {
  const message = input && 'messages' in input ? input.messages[input.messages.length - 1] : input;
  const body = messageBody(message);
  const from = message?.fromName || message?.fromEmail || '';
  const sentAt = message?.sentAt || message?.createdAt || '';
  return `<br><br><div data-forwarded="true"><p>---------- 전달된 메일 ----------</p><p>${from} ${sentAt}</p>${body}</div>`;
}

export function buildThreadRecipients(input: MailThreadDetail | MailThread | null | undefined, currentAccountEmail = '') {
  const thread = input && 'thread' in input ? input.thread : input;
  const current = currentAccountEmail.trim().toLowerCase();
  const participants: MailRecipient[] = Array.isArray(thread?.participants) ? thread.participants : [];
  return dedupeRecipients(
    participants
      .map((participant) => participant.email)
      .filter(Boolean)
      .filter((email) => !current || email.toLowerCase() !== current),
  ).join(', ');
}

export function formatMailBodyHtml(value: string) {
  return value.includes('<') ? value : value.replace(/\n/g, '<br>');
}
