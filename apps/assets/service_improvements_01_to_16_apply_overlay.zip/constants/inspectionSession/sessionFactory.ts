import type { InspectionSession } from '../../types/inspectionSession/session';

export function createEmptyTechnicalGuidanceRelations() {
  return {};
}

export function createInspectionSession(input: any = {}, workspaceId = 'workspace', roundNo = 1): InspectionSession {
  const now = new Date().toISOString();
  return {
    id: `inspection-${Date.now()}`,
    workspaceId,
    currentSection: 'doc1',
    createdAt: now,
    updatedAt: now,
    meta: input.meta ?? {},
    adminSiteSnapshot: input.adminSiteSnapshot ?? {},
    technicalGuidanceRelations: input.technicalGuidanceRelations ?? {},
    document2Overview: {},
    document3Scenes: Array.from({ length: 4 }, () => ({})),
    document4FollowUps: [],
    document7Findings: [],
    document8FutureProcesses: [],
    document11SafetyEducations: [],
    document12Activities: [],
    roundNo,
  };
}
