'use client';

export function SubmitSearchField({
  busy = false,
  buttonClassName = '',
  formClassName = '',
  inputClassName = '',
  onChange,
  onSubmit,
  placeholder = '검색',
  value,
}: {
  busy?: boolean;
  buttonClassName?: string;
  formClassName?: string;
  inputClassName?: string;
  onChange: (value: string) => void;
  onSubmit: () => void;
  placeholder?: string;
  value: string;
}) {
  return (
    <form
      className={formClassName}
      onSubmit={(event) => {
        event.preventDefault();
        if (!busy) onSubmit();
      }}
    >
      <input
        className={inputClassName}
        value={value}
        placeholder={placeholder}
        onChange={(event) => onChange(event.target.value)}
      />
      <button type="submit" className={buttonClassName} disabled={busy}>
        검색
      </button>
    </form>
  );
}
