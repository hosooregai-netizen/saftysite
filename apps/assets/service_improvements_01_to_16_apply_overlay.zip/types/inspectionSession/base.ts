export type InspectionSectionKey = 'doc1' | 'doc2' | 'doc3' | 'doc7' | 'doc8' | 'doc11' | string;
