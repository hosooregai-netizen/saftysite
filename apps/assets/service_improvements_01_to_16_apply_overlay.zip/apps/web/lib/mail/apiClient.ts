'use client';

import type {
  MailAccount,
  MailAttachmentPayload,
  MailboxBox,
  MailboxDraft,
  MailMessage,
  MailProviderStatus,
  MailRecipient,
  MailRecipientSuggestion,
  MailSyncSummary,
  MailThread,
  MailThreadDetail,
} from '@/types/mail';

type RowsResponse<T> = {
  rows: T[];
  total?: number;
};

type MailConnectStartResponse = {
  authorizationUrl: string;
  authorization_url?: string;
  provider: string;
  state: string;
};

async function requestJson<T>(path: string, init: RequestInit = {}): Promise<T> {
  const response = await fetch(`/api/mail${path}`, {
    ...init,
    headers: {
      ...(init.body ? { 'content-type': 'application/json' } : {}),
      ...(init.headers || {}),
    },
    cache: 'no-store',
  });
  const payload = await response.json().catch(() => null);
  if (!response.ok) {
    const detail = payload?.detail || payload?.error || '메일 API 요청에 실패했습니다.';
    throw new Error(String(detail));
  }
  return payload as T;
}

function queryString(input: Record<string, string | number | undefined>) {
  const params = new URLSearchParams();
  Object.entries(input).forEach(([key, value]) => {
    if (value !== undefined && value !== '') params.set(key, String(value));
  });
  const query = params.toString();
  return query ? `?${query}` : '';
}

function normalizeAccount(value: Partial<MailAccount> & Record<string, any>): MailAccount {
  return {
    id: String(value.id || value._id || ''),
    provider: value.provider || 'google',
    email: value.email || '',
    displayName: value.displayName || value.display_name || value.email || '메일 계정',
    mailboxLabel: value.mailboxLabel || value.mailbox_label || (value.provider === 'google' ? '구글 메일' : '메일 계정'),
    isActive: value.isActive ?? value.is_active ?? true,
    isDefault: value.isDefault ?? value.is_default ?? false,
    connectionStatus: value.connectionStatus || value.connection_status || 'connected',
    lastSyncedAt: value.lastSyncedAt || value.last_synced_at || null,
    metadata: value.metadata || {},
  };
}

function normalizeThread(value: Partial<MailThread> & Record<string, any>): MailThread {
  const attachments = Number(value.attachmentCount ?? value.attachment_count ?? 0);
  return {
    id: String(value.id || value._id || ''),
    accountId: value.accountId || value.account_id || '',
    accountEmail: value.accountEmail || value.account_email || '',
    accountDisplayName: value.accountDisplayName || value.account_display_name || '',
    accountLabel: value.accountLabel || value.account_label || value.accountDisplayName || value.accountEmail || '',
    box: value.box || 'inbox',
    subject: value.subject || '',
    snippet: value.snippet || '',
    participants: Array.isArray(value.participants) ? value.participants : [],
    participantsSummary: value.participantsSummary || value.participants_summary || '',
    lastMessageAt: value.lastMessageAt || value.last_message_at || value.updatedAt || value.updated_at || '',
    lastDirection: value.lastDirection || value.last_direction || 'incoming',
    isUnread: Boolean(value.isUnread ?? value.is_unread),
    isStarred: Boolean(value.isStarred ?? value.is_starred),
    hasAttachments: Boolean(value.hasAttachments ?? value.has_attachments ?? attachments > 0),
    attachmentCount: attachments,
    archivedAt: value.archivedAt || value.archived_at || null,
    trashedAt: value.trashedAt || value.trashed_at || null,
    lastOpenedAt: value.lastOpenedAt || value.last_opened_at || null,
    headquarterId: value.headquarterId || value.headquarter_id || null,
    siteId: value.siteId || value.site_id || null,
    reportKey: value.reportKey || value.report_key || null,
  };
}

function normalizeAttachment(value: any) {
  return {
    filename: value?.filename || value?.fileName || 'attachment',
    contentType: value?.contentType || value?.content_type || 'application/octet-stream',
    dataBase64: value?.dataBase64 || value?.data_base64,
    downloadUrl: value?.downloadUrl || value?.download_url,
    sizeBytes: value?.sizeBytes ?? value?.size_bytes ?? 0,
    source: value?.source ?? null,
  };
}

function normalizeMessage(value: Partial<MailMessage> & Record<string, any>): MailMessage {
  const metadata = value.metadata && typeof value.metadata === 'object' ? value.metadata : {};
  return {
    id: String(value.id || value._id || ''),
    threadId: value.threadId || value.thread_id,
    accountId: value.accountId || value.account_id,
    direction: value.direction || 'incoming',
    fromEmail: value.fromEmail || value.from_email || '',
    fromName: value.fromName || value.from_name || null,
    to: Array.isArray(value.to) ? value.to : [],
    cc: Array.isArray(value.cc) ? value.cc : [],
    subject: value.subject || '',
    bodyHtml: value.bodyHtml || value.body_html || value.body || '',
    bodyText: value.bodyText || value.body_text || '',
    body: value.body || value.bodyHtml || value.body_html || value.bodyText || value.body_text || '',
    attachments: Array.isArray(value.attachments)
      ? value.attachments.map(normalizeAttachment)
      : Array.isArray(metadata.attachments)
        ? metadata.attachments.map(normalizeAttachment)
        : [],
    sentAt: value.sentAt || value.sent_at || null,
    createdAt: value.createdAt || value.created_at || '',
  };
}

function normalizeDraft(value: Partial<MailboxDraft> & Record<string, any>): MailboxDraft {
  return {
    id: String(value.id || value._id || ''),
    accountId: value.accountId || value.account_id || '',
    subject: value.subject || '',
    body: value.body || '',
    recipients: Array.isArray(value.recipients) ? value.recipients : [],
    ccRecipients: Array.isArray(value.ccRecipients) ? value.ccRecipients : Array.isArray(value.cc_recipients) ? value.cc_recipients : [],
    attachments: Array.isArray(value.attachments) ? value.attachments.map(normalizeAttachment) : [],
    headquarterId: value.headquarterId || value.headquarter_id || '',
    siteId: value.siteId || value.site_id || '',
    reportKeys: Array.isArray(value.reportKeys) ? value.reportKeys : Array.isArray(value.report_keys) ? value.report_keys : [],
    createdAt: value.createdAt || value.created_at || '',
    updatedAt: value.updatedAt || value.updated_at || '',
  };
}

function normalizeSyncSummary(value: any): MailSyncSummary {
  return {
    backfillAccountCount: Number(value?.backfillAccountCount ?? value?.backfill_account_count ?? 0),
    incrementalAccountCount: Number(value?.incrementalAccountCount ?? value?.incremental_account_count ?? 0),
    messageCount: Number(value?.messageCount ?? value?.message_count ?? 0),
    queuedMessageCount: Number(value?.queuedMessageCount ?? value?.queued_message_count ?? 0),
    syncedAccountCount: Number(value?.syncedAccountCount ?? value?.synced_account_count ?? 0),
    syncErrors: Array.isArray(value?.syncErrors) ? value.syncErrors : Array.isArray(value?.sync_errors) ? value.sync_errors : [],
    threadCount: Number(value?.threadCount ?? value?.thread_count ?? 0),
  };
}

function toSnakePayload(value: any): any {
  if (Array.isArray(value)) return value.map(toSnakePayload);
  if (!value || typeof value !== 'object') return value;
  const map: Record<string, string> = {
    accountId: 'account_id',
    authCode: 'auth_code',
    ccRecipients: 'cc_recipients',
    contentType: 'content_type',
    dataBase64: 'data_base64',
    forwardedFromMessageId: 'forwarded_from_message_id',
    fromName: 'from_name',
    headquarterId: 'headquarter_id',
    redirectUri: 'redirect_uri',
    replyToMessageId: 'reply_to_message_id',
    reportKeys: 'report_keys',
    siteId: 'site_id',
    sizeBytes: 'size_bytes',
    threadId: 'thread_id',
  };
  return Object.fromEntries(Object.entries(value).map(([key, item]) => [map[key] || key, toSnakePayload(item)]));
}

export async function fetchMailAccounts() {
  const response = await requestJson<{ rows: any[] }>('/accounts');
  return { rows: (response.rows || []).map(normalizeAccount) };
}

export async function fetchMailProviderStatuses() {
  const redirectUri = typeof window === 'undefined' ? '' : `${window.location.origin}/mail/connect/google`;
  const response = await requestJson<{ rows: MailProviderStatus[] }>(
    `/providers/status${queryString({ googleRedirectUri: redirectUri })}`,
  );
  return { rows: response.rows || [] };
}

export async function startGoogleMailConnect(): Promise<MailConnectStartResponse> {
  const redirectUri = typeof window === 'undefined' ? '' : `${window.location.origin}/mail/connect/google`;
  const response = await requestJson<any>('/accounts/connect/google/start', {
    method: 'POST',
    body: JSON.stringify({ redirect_uri: redirectUri }),
  });
  return {
    authorizationUrl: response.authorizationUrl || response.authorization_url || response.authUrl || response.url || '',
    authorization_url: response.authorization_url,
    provider: response.provider || 'google',
    state: response.state || '',
  };
}

export function completeGoogleMailConnect(input: {
  authCode: string;
  code?: string;
  provider?: string;
  redirectUri: string;
  state: string;
}) {
  return requestJson<{ account?: MailAccount; rows?: MailAccount[] }>('/accounts/connect/google/complete', {
    method: 'POST',
    body: JSON.stringify({
      auth_code: input.authCode || input.code,
      redirect_uri: input.redirectUri,
      state: input.state,
    }),
  });
}

export function disconnectMailAccount(accountId: string) {
  return requestJson<{ ok?: boolean }>(`/accounts/${encodeURIComponent(accountId)}`, { method: 'DELETE' });
}

export async function fetchMailThreads(input: {
  accountId?: string;
  box?: MailboxBox | string;
  headquarterId?: string;
  query?: string;
  reportKey?: string;
  siteId?: string;
}): Promise<RowsResponse<MailThread>> {
  const query = queryString({
    accountId: input.accountId === 'all' ? undefined : input.accountId,
    box: input.box,
    headquarterId: input.headquarterId,
    query: input.query,
    reportKey: input.reportKey,
    siteId: input.siteId,
  });
  const response = await requestJson<{ rows: any[]; total?: number }>(`/threads${query}`);
  return { rows: (response.rows || []).map(normalizeThread), total: response.total ?? response.rows?.length ?? 0 };
}

export async function fetchMailThreadDetail(threadId: string) {
  const response = await requestJson<any>(`/threads/${encodeURIComponent(threadId)}`);
  return {
    thread: normalizeThread(response.thread || {}),
    messages: Array.isArray(response.messages) ? response.messages.map(normalizeMessage) : [],
  } satisfies MailThreadDetail;
}

export async function patchMailThread(threadId: string, input: {
  isStarred?: boolean;
  isArchived?: boolean;
  isTrashed?: boolean;
  markRead?: boolean;
  restore?: boolean;
}) {
  const response = await requestJson<any>(`/threads/${encodeURIComponent(threadId)}`, {
    method: 'PATCH',
    body: JSON.stringify(toSnakePayload(input)),
  });
  return normalizeThread(response);
}

export async function fetchMailRecipientSuggestions(input: { accountId?: string; query?: string }) {
  const query = queryString({
    accountId: input.accountId === 'all' ? undefined : input.accountId,
    query: input.query,
  });
  const response = await requestJson<{ rows: MailRecipientSuggestion[] }>(`/recipient-suggestions${query}`);
  return { rows: response.rows || [] };
}

export async function fetchMailboxDrafts(input: { accountId?: string; query?: string } = {}) {
  const query = queryString({
    accountId: input.accountId === 'all' ? undefined : input.accountId,
    query: input.query,
  });
  const response = await requestJson<{ rows: any[] }>(`/drafts${query}`);
  return { rows: (response.rows || []).map(normalizeDraft) };
}

export async function createMailboxDraft(input: unknown) {
  const response = await requestJson<any>('/drafts', {
    method: 'POST',
    body: JSON.stringify(toSnakePayload(input)),
  });
  return normalizeDraft(response);
}

export async function updateMailboxDraft(draftId: string, input: unknown) {
  const response = await requestJson<any>(`/drafts/${encodeURIComponent(draftId)}`, {
    method: 'PATCH',
    body: JSON.stringify(toSnakePayload(input)),
  });
  return normalizeDraft(response);
}

export function deleteMailboxDraft(draftId: string) {
  return requestJson<{ ok?: boolean }>(`/drafts/${encodeURIComponent(draftId)}`, { method: 'DELETE' });
}

export async function sendMail(input: {
  accountId: string;
  attachments?: MailAttachmentPayload[];
  body: string;
  cc?: MailRecipient[];
  forwardedFromMessageId?: string;
  fromName?: string;
  headquarterId?: string;
  reportKeys?: string[];
  replyToMessageId?: string;
  siteId?: string;
  subject: string;
  threadId?: string;
  to: MailRecipient[];
}) {
  const response = await requestJson<any>('/send', {
    method: 'POST',
    body: JSON.stringify(toSnakePayload(input)),
  });
  return normalizeMessage(response);
}

export async function syncMail() {
  const response = await requestJson<any>('/sync', { method: 'POST' });
  return normalizeSyncSummary(response);
}
