import type { GenerateInspectionDocumentRequest } from '@/types/documents';

export async function resolveInspectionDocumentRequest(request: Request): Promise<GenerateInspectionDocumentRequest> {
  return (await request.json().catch(() => ({}))) as GenerateInspectionDocumentRequest;
}
