'use client';

import Link from 'next/link';
import styles from '@/features/admin/sections/AdminSectionShared.module.css';
import type { SafetySite } from '@/types/backend';
import type { SafetyHeadquarter } from '@/types/controller';

export function SiteManagementMainPanel({ headquarter, photoHref, reportHref, site, siteEditHref }: { headquarter: SafetyHeadquarter; photoHref: string; reportHref: string; site: SafetySite; siteEditHref: string }) {
  return (
    <section className={styles.detailCard}>
      <div className={styles.panelHeader} style={{ padding: 0, border: 0 }}>
        <div><h2 className={styles.panelTitle}>{site.site_name}</h2><p className={styles.panelHint}>{site.site_address || headquarter.name}</p></div>
        <span className={`${styles.badge} ${site.status === 'active' || !site.status ? styles.badgeSuccess : styles.badgeMuted}`}>{site.status || 'active'}</span>
      </div>
      <div className={styles.quickLinks}>
        <Link className={styles.primaryButton} href={reportHref}>새 보고서 작성</Link>
        <Link className={styles.secondaryButton} href={`/reports?headquarterId=${encodeURIComponent(headquarter.id)}&siteId=${encodeURIComponent(site.id)}`}>보고서 이력</Link>
        <Link className={styles.secondaryButton} href={photoHref}>사진첩</Link>
        <Link className={styles.secondaryButton} href={`/mailbox?headquarterId=${encodeURIComponent(headquarter.id)}&siteId=${encodeURIComponent(site.id)}`}>메일함</Link>
        <Link className={styles.secondaryButton} href={siteEditHref}>현장 수정</Link>
      </div>
      <div className={styles.detailGrid}>
        <div className={styles.detailField}><span className={styles.fieldLabel}>사업장</span><span className={styles.fieldValue}>{headquarter.name}</span></div>
        <div className={styles.detailField}><span className={styles.fieldLabel}>고객/사업장명</span><span className={styles.fieldValue}>{site.client_business_name || '-'}</span></div>
        <div className={styles.detailField}><span className={styles.fieldLabel}>담당자</span><span className={styles.fieldValue}>{site.manager_name || '-'}</span></div>
        <div className={styles.detailField}><span className={styles.fieldLabel}>최근 지도일</span><span className={styles.fieldValue}>{site.last_visit_date || '-'}</span></div>
      </div>
    </section>
  );
}
