export function getCurrentReportMonth() {
  return new Date().toISOString().slice(0, 7);
}
