export default function InstituteWordmark({
  className = '',
  compact = false,
}: {
  className?: string;
  compact?: boolean;
}) {
  return (
    <div className={className} aria-label="대한안전산업연구원">
      <strong>{compact ? '대한안전산업연구원' : '대한안전산업연구원'}</strong>
      {!compact ? <span style={{ display: 'block', fontSize: 11 }}>업무 지원</span> : null}
    </div>
  );
}
