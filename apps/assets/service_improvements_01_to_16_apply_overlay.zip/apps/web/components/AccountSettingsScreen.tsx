'use client';

import { useEffect, useMemo, useState } from 'react';
import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import {
  canUseWorkspaceServerApis,
  isAnonymousSession,
  isAuthenticatedSession,
  isLocalSession,
  peekCachedSession,
  type DemoSession,
} from '@/lib/reportApi';
import {
  beginGoogleWorkspaceAuth,
} from '@/lib/sessionAuthFlow';
import {
  buildGuestWorkspaceCacheSummary,
  markGuestWorkspaceImported,
  readGuestWorkspaceCache,
  type GuestWorkspaceCache,
} from '@/lib/guestWorkspaceCache';
import {
  importGuestWorkspaceCache,
  type GuestWorkspaceImportResponse,
} from '@/lib/workspaceStorageApi';

const packages = [
  { id: 'free', name: '무료 시작', amount: '0원', credits: '2건', note: '워크스페이스 생성 시 즉시 지급' },
  { id: 'starter-10', name: '10건 팩', amount: '30,000원', credits: '10건', note: '기본 팩' },
  { id: 'team-30', name: '30건 팩', amount: '90,000원', credits: '30건', note: '월간 운영' },
  { id: 'agency-100', name: '100건 팩', amount: '300,000원', credits: '100건', note: '대량 처리' },
] as const;

function sessionModeLabel(session: DemoSession | null) {
  if (!session) return '확인 중';
  if (isAuthenticatedSession(session)) return '로그인 완료';
  if (isAnonymousSession(session)) return '임시 작업공간';
  if (isLocalSession(session)) return '로컬 임시 보관';
  return '미확인';
}

function importStatusLabel(cache: GuestWorkspaceCache | null, session: DemoSession | null) {
  if (!cache) return '확인 중';
  if (!session?.workspaceId) return '로그인 후 가져오기 가능';
  if (cache.sync.lastImportedWorkspaceId === session.workspaceId) {
    return cache.sync.lastImportedAt
      ? `가져오기 완료 · ${new Date(cache.sync.lastImportedAt).toLocaleString('ko-KR')}`
      : '가져오기 완료';
  }
  const summary = buildGuestWorkspaceCacheSummary(cache);
  const total = Object.values(summary).reduce((sum, value) => sum + value, 0);
  return total > 0 ? `${total}개 임시 항목 가져오기 가능` : '가져올 임시 항목 없음';
}

function ImportedCounts({ response }: { response: GuestWorkspaceImportResponse | null }) {
  if (!response) return null;
  const rows = [
    ['사업장', response.importedCounts.headquarters],
    ['현장', response.importedCounts.sites],
    ['메일 임시보관', response.importedCounts.mailboxDrafts],
    ['사진첩', response.importedCounts.photoAlbum],
    ['웹하드 항목', response.importedCounts.driveItems],
    ['웹하드 공유', response.importedCounts.driveShares],
  ] as const;
  return (
    <div className="row-meta">
      가져오기 완료:{' '}
      {rows
        .filter(([, count]) => count > 0)
        .map(([label, count]) => `${label} ${count}`)
        .join(', ') || '새로 가져온 항목 없음'}
    </div>
  );
}

export function AccountSettingsScreen() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [session, setSession] = useState<DemoSession | null>(null);
  const [authBusy, setAuthBusy] = useState(false);
  const [guestCache, setGuestCache] = useState<GuestWorkspaceCache | null>(null);
  const [guestImportBusy, setGuestImportBusy] = useState(false);
  const [guestImportResult, setGuestImportResult] = useState<GuestWorkspaceImportResponse | null>(null);
  const [guestImportError, setGuestImportError] = useState('');

  const billingNotice = searchParams.get('billingNotice') || '';
  const billingError = searchParams.get('billingError') || '';
  const authError = searchParams.get('authError') || '';
  const authRequired = searchParams.get('auth') === 'required';
  const intent = searchParams.get('intent') || '';
  const intentPackage = searchParams.get('package') || '';
  const next = searchParams.get('next') || '';
  const canUseWorkspace = canUseWorkspaceServerApis(session);
  const guestSummary = useMemo(
    () => (guestCache ? buildGuestWorkspaceCacheSummary(guestCache) : null),
    [guestCache],
  );
  const guestTotal = guestSummary
    ? Object.values(guestSummary).reduce((sum, value) => sum + value, 0)
    : 0;
  const alreadyImported =
    Boolean(guestCache && session?.workspaceId && guestCache.sync.lastImportedWorkspaceId === session.workspaceId);

  useEffect(() => {
    setSession(peekCachedSession());
    void readGuestWorkspaceCache().then(setGuestCache).catch(() => setGuestCache(null));
  }, [searchParams]);

  useEffect(() => {
    if (!canUseWorkspace || intent !== 'billing' || !intentPackage) return;
    router.replace(`/billing/checkout?package=${encodeURIComponent(intentPackage)}`);
  }, [canUseWorkspace, intent, intentPackage, router]);

  useEffect(() => {
    if (!canUseWorkspace || intent || !authRequired || !next) return;
    router.replace(next);
  }, [authRequired, canUseWorkspace, intent, next, router]);

  const handleGoogleAuth = async () => {
    setAuthBusy(true);
    try {
      if (canUseWorkspace) {
        router.push('/account#account');
        return;
      }
      const currentSession: DemoSession | null = peekCachedSession() ?? session;
      const nextPath =
        intent === 'billing' && intentPackage
          ? `/billing/checkout?package=${encodeURIComponent(intentPackage)}`
          : next || '/account#account';
      const anonymousToken =
        currentSession && isAnonymousSession(currentSession) ? currentSession.token : null;
      await beginGoogleWorkspaceAuth({
        anonymousToken,
        nextPath,
      });
    } catch (error) {
      router.replace(
        `/account?authError=${encodeURIComponent(
          error instanceof Error ? error.message : '구글 로그인으로 이동하지 못했습니다.',
        )}#account`,
      );
    } finally {
      setAuthBusy(false);
    }
  };

  const handleImportGuestCache = async () => {
    setGuestImportBusy(true);
    setGuestImportError('');
    setGuestImportResult(null);
    try {
      if (!session || !canUseWorkspaceServerApis(session)) {
        throw new Error('로그인 후 임시 자료를 가져올 수 있습니다.');
      }
      const cache = await readGuestWorkspaceCache();
      const summary = buildGuestWorkspaceCacheSummary(cache);
      const total = Object.values(summary).reduce((sum, value) => sum + value, 0);
      if (total === 0) {
        setGuestCache(cache);
        throw new Error('가져올 임시 자료가 없습니다.');
      }
      if (cache.sync.lastImportedWorkspaceId === session.workspaceId) {
        setGuestCache(cache);
        throw new Error('이미 현재 작업공간으로 가져온 임시 자료입니다.');
      }
      const result = await importGuestWorkspaceCache(session, cache);
      await markGuestWorkspaceImported(session.workspaceId);
      setGuestImportResult(result);
      setGuestCache(await readGuestWorkspaceCache());
    } catch (error) {
      setGuestImportError(error instanceof Error ? error.message : '임시 자료를 가져오지 못했습니다.');
    } finally {
      setGuestImportBusy(false);
    }
  };

  return (
    <div className="erp-page">
      <section className="page-header-card" id="account">
        <div>
          <span className="page-kicker">Settings</span>
          <h1 className="page-title">설정</h1>
          <p className="page-meta-line">
            앱 로그인, 임시 자료 가져오기, 결제 진입을 관리합니다. Gmail 연결은 메일함에서 별도로 진행합니다.
          </p>
        </div>
      </section>

      {billingNotice ? <div className="row-meta">{billingNotice}</div> : null}
      {billingError ? <div className="row-meta">{billingError}</div> : null}
      {authError ? <div className="row-meta">{authError}</div> : null}
      {authRequired && !canUseWorkspace ? <div className="row-meta">계정 연결 후 계속 진행합니다.</div> : null}

      <section className="erp-two-column">
        <article className="erp-panel">
          <div className="erp-panel-header">
            <div>
              <h2>계정과 작업공간</h2>
              <p className="page-meta-line">
                Google Workspace 로그인은 앱 계정과 작업공간을 연결합니다. 구글 메일 발송은 메일함의 “Google 메일 연결”에서 별도로 설정합니다.
              </p>
            </div>
          </div>

          <dl className="detail-grid">
            <div>
              <dt>계정 상태</dt>
              <dd>{sessionModeLabel(session)}</dd>
            </div>
            <div>
              <dt>표시 이름</dt>
              <dd>{session?.userName || '-'}</dd>
            </div>
            <div>
              <dt>작업공간</dt>
              <dd>{session?.workspaceName || '-'}</dd>
            </div>
            <div>
              <dt>로그인 방식</dt>
              <dd>{canUseWorkspace ? 'Google Workspace' : '미연결'}</dd>
            </div>
          </dl>

          <div className="workspace-header-actions" style={{ marginTop: 20 }}>
            {!canUseWorkspace ? (
              <button type="button" className="erp-button erp-button-primary" onClick={() => void handleGoogleAuth()} disabled={authBusy}>
                {authBusy ? '이동 중...' : 'Google로 로그인'}
              </button>
            ) : (
              <Link className="erp-button erp-button-secondary" href="/mailbox">
                메일함에서 Gmail 연결 관리
              </Link>
            )}
          </div>

          <div className="row-meta" style={{ marginTop: 16 }}>
            앱 로그인은 `/auth/google/callback`, Gmail 연결은 `/mail/connect/google` 흐름을 사용합니다.
          </div>
        </article>

        <article className="erp-panel">
          <div className="erp-panel-header">
            <div>
              <h2>임시 자료 가져오기</h2>
              <p className="page-meta-line">
                비로그인 상태에서 만든 사업장/현장, 사진첩, 웹하드, 메일 임시보관 자료를 로그인한 작업공간으로 가져옵니다.
              </p>
            </div>
          </div>

          <dl className="detail-grid">
            <div>
              <dt>가져오기 상태</dt>
              <dd>{importStatusLabel(guestCache, session)}</dd>
            </div>
            <div>
              <dt>사업장/현장</dt>
              <dd>{guestSummary ? `${guestSummary.headquarters} / ${guestSummary.sites}` : '-'}</dd>
            </div>
            <div>
              <dt>사진첩</dt>
              <dd>{guestSummary?.photoAlbum ?? '-'}</dd>
            </div>
            <div>
              <dt>웹하드</dt>
              <dd>{guestSummary ? `${guestSummary.driveItems}개 항목 · 공유 ${guestSummary.driveShares}` : '-'}</dd>
            </div>
            <div>
              <dt>메일 임시보관</dt>
              <dd>{guestSummary?.mailboxDrafts ?? '-'}</dd>
            </div>
          </dl>

          <div className="workspace-header-actions" style={{ marginTop: 20 }}>
            <button
              type="button"
              className="erp-button erp-button-primary"
              onClick={() => void handleImportGuestCache()}
              disabled={!canUseWorkspace || guestImportBusy || guestTotal === 0 || alreadyImported}
            >
              {guestImportBusy ? '가져오는 중...' : '임시 자료 가져오기'}
            </button>
          </div>

          {guestImportError ? <div className="row-meta">{guestImportError}</div> : null}
          <ImportedCounts response={guestImportResult} />
        </article>

        <article className="erp-panel" id="billing">
          <div className="erp-panel-header">
            <div>
              <h2>결제/크레딧</h2>
              <p className="page-meta-line">패키지를 선택하면 결제 준비 화면으로 이동합니다.</p>
            </div>
          </div>
          <div className="package-grid">
            {packages.map((item) => (
              <article key={item.id} className="package-card settings-package-card">
                <span className="page-kicker">{item.credits}</span>
                <h3>{item.name}</h3>
                <strong className="package-amount">{item.amount}</strong>
                <p>{item.note}</p>
                {item.id === 'free' ? (
                  <button type="button" className="erp-button erp-button-secondary" disabled>
                    기본 제공
                  </button>
                ) : (
                  <button
                    type="button"
                    className="erp-button erp-button-primary"
                    onClick={() => {
                      if (canUseWorkspace) {
                        router.push(`/billing/checkout?package=${item.id}`);
                        return;
                      }
                      router.push(`/account?auth=required&intent=billing&package=${encodeURIComponent(item.id)}#billing`);
                    }}
                  >
                    결제하기
                  </button>
                )}
              </article>
            ))}
          </div>
        </article>

        <article className="erp-panel">
          <div className="erp-panel-header">
            <div>
              <h2>메일 계정 연결</h2>
              <p className="page-meta-line">
                Gmail 계정 연결은 메일 읽기/발송 권한을 다루므로 앱 로그인과 별도로 메일함에서 진행합니다.
              </p>
            </div>
          </div>
          <div className="workspace-header-actions">
            <Link className="erp-button erp-button-secondary" href="/mailbox">
              메일함으로 이동
            </Link>
          </div>
        </article>
      </section>
    </div>
  );
}
