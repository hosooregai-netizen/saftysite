export async function buildStandardInspectionHwpxDocument(input: unknown): Promise<Uint8Array> {
  const body = JSON.stringify(input ?? {}, null, 2);
  return new TextEncoder().encode(`HWPX placeholder\n${body}`);
}
