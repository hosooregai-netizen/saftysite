'use client';

import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import { useEffect, useMemo, useState } from 'react';
import {
  bootstrapReportSession,
  hasGeneratedReportSnapshot,
  listReports,
  readLastGeneratedReportSession,
  type ReportRecord,
  type ReportExportRecord,
} from '@/lib/reportApi';

type LoadState = 'idle' | 'loading' | 'loaded' | 'error';
type StatusFilter = 'all' | 'collecting' | 'generating' | 'review' | 'reviewed' | 'exported';
type ExportFilter = 'all' | 'not_exported' | 'pdf' | 'hwpx' | 'both';
type SortMode = 'updated_desc' | 'visit_desc' | 'visit_asc' | 'review_pending_desc' | 'export_status';

type ReportListStatus = {
  key: StatusFilter;
  label: string;
  tone: 'warning' | 'neutral' | 'info' | 'success';
};

function safeText(value: unknown): string {
  return typeof value === 'string' ? value : '';
}

function normalizeSearchText(value: string): string {
  return value.trim().toLowerCase();
}

function getReviewPendingCount(report: ReportRecord): number {
  return (report.payload.reviewMeta?.reviewQueue || []).filter((item) => Boolean(item.needsReview)).length;
}

function getFindingCount(report: ReportRecord): number {
  return Array.isArray(report.payload.findingCandidates) ? report.payload.findingCandidates.length : 0;
}

function getReportListStatus(report: ReportRecord): ReportListStatus {
  if (report.status === 'exported' || report.exports.length > 0) {
    return { key: 'exported', label: '출력 완료', tone: 'success' };
  }
  if (report.review_completed || report.status === 'review_completed') {
    return { key: 'reviewed', label: '검토 완료', tone: 'info' };
  }
  if (report.payload.currentSection === 'ai-generating') {
    return { key: 'generating', label: '생성 중', tone: 'info' };
  }
  if (report.status === 'draft_ready') {
    return { key: 'review', label: '검토 필요', tone: 'warning' };
  }
  return { key: 'collecting', label: '사진 수집 중', tone: 'neutral' };
}

function getExportFormats(report: ReportRecord) {
  return new Set(report.exports.map((item) => item.format));
}

function getExportStatus(report: ReportRecord): { key: ExportFilter; label: string; detail: string } {
  const formats = getExportFormats(report);
  if (formats.has('pdf') && formats.has('hwpx')) {
    return { key: 'both', label: 'PDF/HWPX 출력', detail: `${report.exports.length}회 출력` };
  }
  if (formats.has('pdf')) {
    return { key: 'pdf', label: 'PDF 출력', detail: `${report.exports.length}회 출력` };
  }
  if (formats.has('hwpx')) {
    return { key: 'hwpx', label: 'HWPX 출력', detail: `${report.exports.length}회 출력` };
  }
  return { key: 'not_exported', label: '미출력', detail: '출력 이력 없음' };
}

function getLatestExport(report: ReportRecord): ReportExportRecord | null {
  if (!report.exports.length) return null;
  return [...report.exports].sort((left, right) => right.created_at.localeCompare(left.created_at))[0] ?? null;
}

function formatDateTime(value: string | null | undefined): string {
  if (!value) return '-';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) {
    return value.slice(0, 16).replace('T', ' ');
  }
  return new Intl.DateTimeFormat('ko-KR', {
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
  }).format(date);
}

function formatVisitDate(value: string | null | undefined): string {
  if (!value) return '지도일 미입력';
  return value;
}

function buildReportHref(report: ReportRecord): string {
  return hasGeneratedReportSnapshot(report.id) ? `/reports/${report.id}?entry=generated` : `/reports/${report.id}`;
}

function reportMatchesQuery(report: ReportRecord, query: string): boolean {
  const normalized = normalizeSearchText(query);
  if (!normalized) return true;
  const meta = report.payload.reportMeta;
  const haystack = [
    report.id,
    report.status,
    meta.siteName,
    meta.customerName,
    meta.drafterName,
    meta.visitDate,
    meta.siteAddress,
    getReportListStatus(report).label,
    getExportStatus(report).label,
  ]
    .filter(Boolean)
    .join(' ')
    .toLowerCase();
  return haystack.includes(normalized);
}

function reportMatchesStatus(report: ReportRecord, filter: StatusFilter): boolean {
  if (filter === 'all') return true;
  return getReportListStatus(report).key === filter;
}

function reportMatchesExport(report: ReportRecord, filter: ExportFilter): boolean {
  if (filter === 'all') return true;
  return getExportStatus(report).key === filter;
}

function compareReports(left: ReportRecord, right: ReportRecord, sortMode: SortMode): number {
  if (sortMode === 'visit_desc') {
    return safeText(right.payload.reportMeta.visitDate).localeCompare(safeText(left.payload.reportMeta.visitDate));
  }
  if (sortMode === 'visit_asc') {
    return safeText(left.payload.reportMeta.visitDate).localeCompare(safeText(right.payload.reportMeta.visitDate));
  }
  if (sortMode === 'review_pending_desc') {
    return getReviewPendingCount(right) - getReviewPendingCount(left) || right.updated_at.localeCompare(left.updated_at);
  }
  if (sortMode === 'export_status') {
    return getExportStatus(left).label.localeCompare(getExportStatus(right).label, 'ko') || right.updated_at.localeCompare(left.updated_at);
  }
  return right.updated_at.localeCompare(left.updated_at);
}

function FilterButton({
  active,
  children,
  onClick,
}: {
  active: boolean;
  children: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      className={`workspace-chip ${active ? 'workspace-chip-active' : ''}`}
      onClick={onClick}
      style={{ cursor: 'pointer' }}
    >
      {children}
    </button>
  );
}

function ReportExportHistory({ report }: { report: ReportRecord }) {
  const latest = getLatestExport(report);
  if (!latest) {
    return <span className="row-meta">아직 PDF/HWPX 출력 이력이 없습니다.</span>;
  }
  const charged = report.exports.some((item) => item.first_charge_applied);
  return (
    <span className="row-meta">
      최근 {latest.format.toUpperCase()} · {formatDateTime(latest.created_at)} · {charged ? '크레딧 차감 완료' : '추가 차감 없음'}
    </span>
  );
}

export function ReportsOverview() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [loadState, setLoadState] = useState<LoadState>('idle');
  const [loadError, setLoadError] = useState('');
  const [reports, setReports] = useState<ReportRecord[]>([]);
  const [query, setQuery] = useState(searchParams.get('query') || '');
  const [statusFilter, setStatusFilter] = useState<StatusFilter>((searchParams.get('status') as StatusFilter) || 'all');
  const [exportFilter, setExportFilter] = useState<ExportFilter>((searchParams.get('export') as ExportFilter) || 'all');
  const [sortMode, setSortMode] = useState<SortMode>((searchParams.get('sort') as SortMode) || 'updated_desc');

  useEffect(() => {
    let cancelled = false;

    async function load() {
      setLoadState('loading');
      setLoadError('');

      try {
        const session = await bootstrapReportSession({
          preferredSession: readLastGeneratedReportSession(),
        });
        const nextReports = await listReports(session);

        if (cancelled) return;
        setReports(nextReports);
        setLoadState('loaded');
      } catch (error) {
        if (cancelled) return;
        setLoadState('error');
        setLoadError(error instanceof Error ? error.message : '목록을 불러오지 못했습니다.');
      }
    }

    void load();
    return () => {
      cancelled = true;
    };
  }, []);

  const summary = useMemo(() => {
    return reports.reduce(
      (acc, report) => {
        const status = getReportListStatus(report).key;
        const exportStatus = getExportStatus(report).key;
        acc.total += 1;
        acc[status] += 1;
        if (exportStatus === 'not_exported') acc.notExported += 1;
        if (exportStatus !== 'not_exported') acc.exported += 1;
        acc.reviewPending += getReviewPendingCount(report);
        return acc;
      },
      {
        collecting: 0,
        exported: 0,
        generating: 0,
        notExported: 0,
        review: 0,
        reviewed: 0,
        reviewPending: 0,
        total: 0,
      },
    );
  }, [reports]);

  const filteredReports = useMemo(() => {
    return reports
      .filter((report) => reportMatchesQuery(report, query))
      .filter((report) => reportMatchesStatus(report, statusFilter))
      .filter((report) => reportMatchesExport(report, exportFilter))
      .sort((left, right) => compareReports(left, right, sortMode));
  }, [exportFilter, query, reports, sortMode, statusFilter]);

  const resetFilters = () => {
    setQuery('');
    setStatusFilter('all');
    setExportFilter('all');
    setSortMode('updated_desc');
  };

  return (
    <div className="erp-page">
      <section className="page-header-card">
        <div>
          <span className="page-kicker">보고서 보기</span>
          <h1 className="page-title">기술지도 보고서 목록</h1>
          <p className="page-meta-line">
            작성 중인 보고서와 검토 상태, PDF/HWPX 출력 이력을 한 화면에서 확인합니다.
          </p>
        </div>
        <div className="workspace-header-actions">
          <span className="workspace-chip workspace-chip-active">보고서 관리</span>
          <Link href="/reports/new" className="erp-button erp-button-primary">
            새 보고서 작성
          </Link>
        </div>
      </section>

      <section className="erp-panel">
        <div className="erp-panel-header">
          <div>
            <h2>작성 및 출력 이력</h2>
            <p className="page-meta-line">
              전체 {summary.total}건 · 검토 필요 {summary.review}건 · 검토 대기 {summary.reviewPending}건 · 출력 완료 {summary.exported}건
            </p>
          </div>
          <div className="erp-toolbar">
            <input
              className="erp-input erp-search"
              value={query}
              placeholder="현장명, 사업장, 작성자, 지도일, 상태 검색"
              onChange={(event) => setQuery(event.target.value)}
            />
            <select className="erp-select" value={sortMode} aria-label="정렬" onChange={(event) => setSortMode(event.target.value as SortMode)}>
              <option value="updated_desc">최종수정순</option>
              <option value="visit_desc">지도일 최신순</option>
              <option value="visit_asc">지도일 오래된순</option>
              <option value="review_pending_desc">검토대기 많은순</option>
              <option value="export_status">출력 상태순</option>
            </select>
          </div>
        </div>

        <div className="erp-toolbar" style={{ flexWrap: 'wrap', marginBottom: 12 }}>
          <FilterButton active={statusFilter === 'all'} onClick={() => setStatusFilter('all')}>전체</FilterButton>
          <FilterButton active={statusFilter === 'collecting'} onClick={() => setStatusFilter('collecting')}>사진 수집중 {summary.collecting}</FilterButton>
          <FilterButton active={statusFilter === 'generating'} onClick={() => setStatusFilter('generating')}>생성중 {summary.generating}</FilterButton>
          <FilterButton active={statusFilter === 'review'} onClick={() => setStatusFilter('review')}>검토 필요 {summary.review}</FilterButton>
          <FilterButton active={statusFilter === 'reviewed'} onClick={() => setStatusFilter('reviewed')}>검토 완료 {summary.reviewed}</FilterButton>
          <FilterButton active={statusFilter === 'exported'} onClick={() => setStatusFilter('exported')}>출력 완료 {summary.exported}</FilterButton>
        </div>

        <div className="erp-toolbar" style={{ flexWrap: 'wrap', marginBottom: 16 }}>
          <FilterButton active={exportFilter === 'all'} onClick={() => setExportFilter('all')}>전체 출력상태</FilterButton>
          <FilterButton active={exportFilter === 'not_exported'} onClick={() => setExportFilter('not_exported')}>미출력 {summary.notExported}</FilterButton>
          <FilterButton active={exportFilter === 'pdf'} onClick={() => setExportFilter('pdf')}>PDF</FilterButton>
          <FilterButton active={exportFilter === 'hwpx'} onClick={() => setExportFilter('hwpx')}>HWPX</FilterButton>
          <FilterButton active={exportFilter === 'both'} onClick={() => setExportFilter('both')}>PDF/HWPX</FilterButton>
          <button type="button" className="erp-button erp-button-text" onClick={resetFilters}>필터 초기화</button>
        </div>

        {loadState === 'loading' ? <div className="row-meta">목록 불러오는 중</div> : null}
        {loadState === 'error' ? <div className="row-meta">{loadError}</div> : null}
        {loadState === 'loaded' ? (
          <div className="report-table">
            <div className="report-table-head">
              <span>순번/지도일</span>
              <span>보고서명</span>
              <span>진행상태</span>
              <span>최종수정</span>
              <span>출력 이력</span>
              <span>작업</span>
            </div>
            {filteredReports.length > 0 ? (
              filteredReports.map((report, index) => {
                const status = getReportListStatus(report);
                const exportStatus = getExportStatus(report);
                const reviewPendingCount = getReviewPendingCount(report);
                const findingCount = getFindingCount(report);
                const reportHref = buildReportHref(report);
                const rowNumber = filteredReports.length - index;

                return (
                  <article
                    key={report.id}
                    className="report-row"
                    role="button"
                    tabIndex={0}
                    onClick={() => router.push(reportHref)}
                    onKeyDown={(event) => {
                      if (event.key === 'Enter' || event.key === ' ') {
                        event.preventDefault();
                        router.push(reportHref);
                      }
                    }}
                  >
                    <div className="report-row-primary">
                      <strong>{rowNumber}차</strong>
                      <span>{formatVisitDate(report.payload.reportMeta.visitDate)}</span>
                    </div>
                    <div className="report-row-title">
                      <strong>{report.payload.reportMeta.siteName || '현장명 미입력'}</strong>
                      <span>{report.payload.reportMeta.customerName || '사업장명 미입력'}</span>
                      <span className="row-meta">작성자 {report.payload.reportMeta.drafterName || '-'}</span>
                    </div>
                    <div>
                      <span className={`status-badge status-${status.tone}`}>{status.label}</span>
                      <p className="row-meta">검토대기 {reviewPendingCount}건 · 지적 {findingCount}건</p>
                    </div>
                    <div className="row-meta-block">
                      <strong>{formatDateTime(report.updated_at)}</strong>
                      <span>{report.sessionMode === 'local' || report.localOnly ? '로컬 임시' : report.workspace_id}</span>
                    </div>
                    <div className="row-meta-block">
                      <strong>{exportStatus.label}</strong>
                      <ReportExportHistory report={report} />
                    </div>
                    <div className="row-actions" onClick={(event) => event.stopPropagation()}>
                      <Link href={reportHref} className="erp-button erp-button-secondary">
                        열기
                      </Link>
                      <Link
                        href={`/reports/new${report.headquarter_id || report.site_id ? `?${new URLSearchParams({
                          ...(report.headquarter_id ? { headquarterId: report.headquarter_id } : {}),
                          ...(report.site_id ? { siteId: report.site_id } : {}),
                        }).toString()}` : ''}`}
                        className="erp-button erp-button-text"
                      >
                        같은 현장 새 작성
                      </Link>
                    </div>
                  </article>
                );
              })
            ) : (
              <article className="report-row">
                <div className="report-row-title">
                  <strong>{reports.length > 0 ? '조건에 맞는 보고서가 없습니다.' : '저장된 보고서가 없습니다.'}</strong>
                  <span>{reports.length > 0 ? '검색어와 필터를 조정해 주세요.' : '새 보고서를 시작해 주세요.'}</span>
                </div>
                <div className="row-actions">
                  {reports.length > 0 ? (
                    <button type="button" className="erp-button erp-button-secondary" onClick={resetFilters}>
                      필터 초기화
                    </button>
                  ) : (
                    <Link href="/reports/new" className="erp-button erp-button-primary">
                      새 보고서 작성
                    </Link>
                  )}
                </div>
              </article>
            )}
          </div>
        ) : null}
      </section>
    </div>
  );
}
