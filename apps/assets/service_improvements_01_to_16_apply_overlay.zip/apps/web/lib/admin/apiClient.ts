'use client';

import type { SafetySite } from '@/types/backend';

export async function fetchAdminSitesList(input: {
  limit?: number;
  offset?: number;
  query?: string;
  sortBy?: string;
  sortDir?: 'asc' | 'desc' | string;
} = {}): Promise<{ rows: SafetySite[]; total: number }> {
  const params = new URLSearchParams();
  params.set('limit', String(input.limit ?? 100));
  params.set('offset', String(input.offset ?? 0));
  if (input.query) params.set('query', input.query);
  if (input.sortBy) params.set('sort_by', input.sortBy);
  if (input.sortDir) params.set('sort_dir', input.sortDir);
  const response = await fetch(`/api/admin/sites/list?${params.toString()}`, { cache: 'no-store' });
  const payload = await response.json().catch(() => null);
  if (!response.ok) throw new Error(String(payload?.detail || payload?.error || '현장 목록을 불러오지 못했습니다.'));
  if (Array.isArray(payload)) return { rows: payload, total: payload.length };
  return { rows: payload?.rows || [], total: payload?.total ?? payload?.rows?.length ?? 0 };
}
