'use client';

import styles from '@/features/admin/sections/AdminSectionShared.module.css';

export function SitesFilterMenu({
  activeCount = 0,
  assignmentFilter = 'all',
  onAssignmentFilterChange,
  onReset,
  onStatusFilterChange,
  statusFilter = 'all',
}: any) {
  return (
    <div className={styles.filterBar}>
      <button type="button" className={`${styles.filterButton} ${statusFilter === 'all' ? styles.filterButtonActive : ''}`} onClick={() => onStatusFilterChange?.('all')}>전체 상태</button>
      <button type="button" className={`${styles.filterButton} ${statusFilter === 'active' ? styles.filterButtonActive : ''}`} onClick={() => onStatusFilterChange?.('active')}>진행 중</button>
      <button type="button" className={`${styles.filterButton} ${statusFilter === 'completed' ? styles.filterButtonActive : ''}`} onClick={() => onStatusFilterChange?.('completed')}>완료</button>
      <button type="button" className={`${styles.filterButton} ${assignmentFilter === 'assigned' ? styles.filterButtonActive : ''}`} onClick={() => onAssignmentFilterChange?.('assigned')}>배정됨</button>
      <button type="button" className={`${styles.filterButton} ${assignmentFilter === 'unassigned' ? styles.filterButtonActive : ''}`} onClick={() => onAssignmentFilterChange?.('unassigned')}>미배정</button>
      <button type="button" className={styles.filterButton} onClick={onReset}>초기화 {activeCount ? `(${activeCount})` : ''}</button>
    </div>
  );
}
