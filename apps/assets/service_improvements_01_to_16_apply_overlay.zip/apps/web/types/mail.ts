export type MailProvider = 'google' | 'naver' | 'naver_works' | string;
export type MailboxBox = 'all' | 'inbox' | 'sent' | 'drafts' | 'starred' | 'trash';
export type MailDirection = 'incoming' | 'outgoing';

export interface MailRecipient {
  email: string;
  name: string | null;
}

export interface MailAttachmentRecord {
  filename: string;
  contentType: string;
  dataBase64?: string;
  downloadUrl?: string;
  sizeBytes?: number;
  source?: string | null;
}

export type MailAttachmentPayload = MailAttachmentRecord;

export interface MailAccount {
  id: string;
  provider: MailProvider;
  email: string;
  displayName: string;
  mailboxLabel: string;
  isActive: boolean;
  isDefault: boolean;
  connectionStatus?: string;
  lastSyncedAt?: string | null;
  metadata?: {
    initialBackfillCompleted?: boolean;
    syncError?: string | null;
    syncStatus?: string;
    [key: string]: unknown;
  } | Record<string, unknown>;
}

export interface MailProviderStatus {
  provider: MailProvider;
  enabled?: boolean;
  available?: boolean;
  connected?: boolean;
  label?: string;
  message?: string;
  authUrl?: string | null;
  authorizationUrl?: string | null;
  defaultRedirectUri?: string;
  allowedRedirectUris?: string[];
  requestedRedirectUri?: string;
  isRedirectAllowed?: boolean;
  missingFields?: string[];
  reason?: string | null;
}

export interface MailThread {
  id: string;
  accountId: string;
  accountEmail: string;
  accountDisplayName: string;
  accountLabel?: string;
  box: MailboxBox | string;
  subject: string;
  snippet: string;
  participants: MailRecipient[];
  participantsSummary?: string;
  lastMessageAt: string;
  lastDirection: MailDirection;
  isUnread: boolean;
  isStarred: boolean;
  hasAttachments?: boolean;
  attachmentCount: number;
  archivedAt?: string | null;
  trashedAt?: string | null;
  lastOpenedAt?: string | null;
  headquarterId?: string | null;
  siteId?: string | null;
  reportKey?: string | null;
}

export interface MailMessage {
  id: string;
  threadId?: string;
  accountId?: string;
  direction: MailDirection;
  fromEmail: string;
  fromName?: string | null;
  to: MailRecipient[];
  cc?: MailRecipient[];
  subject: string;
  bodyHtml?: string;
  bodyText?: string;
  body?: string;
  attachments: MailAttachmentRecord[];
  sentAt?: string | null;
  createdAt: string;
}

export interface MailThreadDetail {
  thread: MailThread;
  messages: MailMessage[];
}

export interface MailboxDraft {
  id: string;
  accountId: string;
  subject: string;
  body: string;
  recipients: string[];
  ccRecipients: string[];
  attachments: MailAttachmentRecord[];
  headquarterId?: string;
  siteId?: string;
  reportKeys: string[];
  createdAt: string;
  updatedAt: string;
}

export interface MailRecipientSuggestion {
  email: string;
  name: string | null;
  source?: string;
  label?: string;
}

export interface MailSyncSummary {
  backfillAccountCount: number;
  incrementalAccountCount: number;
  messageCount: number;
  queuedMessageCount: number;
  syncedAccountCount: number;
  syncErrors: string[];
  threadCount: number;
}
