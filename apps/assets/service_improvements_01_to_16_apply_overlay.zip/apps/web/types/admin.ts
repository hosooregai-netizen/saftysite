export interface TableSortState<T extends string = string> {
  key: T;
  direction: 'asc' | 'desc';
}
