'use client';

export function MailboxComposeToolbar({
  canSaveDraft = true,
  canSend = true,
  draftStatus = '',
  onAttachFiles,
  onClose,
  onCommand,
  onLink,
  onSaveDraft,
  onSend,
}: {
  canSaveDraft?: boolean;
  canSend?: boolean;
  draftStatus?: string;
  onAttachFiles?: (files: FileList | null) => void;
  onClose?: () => void;
  onCommand?: (command: string, value?: string) => void;
  onLink?: () => void;
  onSaveDraft?: () => void;
  onSend?: () => void;
}) {
  const buttonStyle = {
    alignItems: 'center',
    border: '1px solid #d2d7e0',
    borderRadius: 10,
    background: '#fff',
    cursor: 'pointer',
    display: 'inline-flex',
    fontWeight: 700,
    gap: 6,
    minHeight: 34,
    padding: '0 10px',
  } as const;

  return (
    <div
      aria-label="메일 본문 서식 도구"
      style={{
        alignItems: 'center',
        borderBottom: '1px solid #e0e3e7',
        display: 'flex',
        flexWrap: 'wrap',
        gap: 6,
        padding: 8,
      }}
    >
      <button type="button" style={buttonStyle} onClick={() => onCommand?.('bold')} aria-label="굵게">
        B
      </button>
      <button type="button" style={buttonStyle} onClick={() => onCommand?.('italic')} aria-label="기울임">
        I
      </button>
      <button type="button" style={buttonStyle} onClick={() => onCommand?.('underline')} aria-label="밑줄">
        U
      </button>
      <button type="button" style={buttonStyle} onClick={onLink} aria-label="링크 삽입">
        링크
      </button>

      {onAttachFiles ? (
        <label style={buttonStyle}>
          첨부
          <input type="file" multiple hidden onChange={(event) => onAttachFiles(event.currentTarget.files)} />
        </label>
      ) : null}

      <span style={{ flex: 1 }} />

      {draftStatus ? <span style={{ color: '#5f6368', fontSize: 12 }}>{draftStatus}</span> : null}

      {onSaveDraft ? (
        <button type="button" style={buttonStyle} onClick={onSaveDraft} disabled={!canSaveDraft}>
          임시저장
        </button>
      ) : null}
      {onSend ? (
        <button
          type="button"
          style={{ ...buttonStyle, background: '#0b57d0', borderColor: '#0b57d0', color: '#fff' }}
          onClick={onSend}
          disabled={!canSend}
        >
          보내기
        </button>
      ) : null}
      {onClose ? (
        <button type="button" style={buttonStyle} onClick={onClose}>
          닫기
        </button>
      ) : null}
    </div>
  );
}

export default MailboxComposeToolbar;
