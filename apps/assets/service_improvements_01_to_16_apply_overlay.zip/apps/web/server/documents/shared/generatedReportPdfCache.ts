const cache = new Map<string, Uint8Array>();

export function getGeneratedReportPdf(key: string) {
  return cache.get(key) ?? null;
}

export function setGeneratedReportPdf(key: string, value: Uint8Array) {
  cache.set(key, value);
}
