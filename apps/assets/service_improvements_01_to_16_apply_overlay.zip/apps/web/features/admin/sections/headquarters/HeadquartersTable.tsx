'use client';

import Link from 'next/link';
import styles from '@/features/admin/sections/AdminSectionShared.module.css';
import type { SafetyHeadquarter } from '@/types/controller';

function statusBadge(item: SafetyHeadquarter) {
  return item.is_active === false ? <span className={`${styles.badge} ${styles.badgeMuted}`}>비활성</span> : <span className={`${styles.badge} ${styles.badgeSuccess}`}>활성</span>;
}

export function HeadquartersTable({
  busy,
  filteredHeadquarters = [],
  onCreateRequest,
  onDeleteRequest,
  onEditRequest,
  onExportRequest,
  onOpenSitesRequest,
  onPageChange,
  onQueryChange,
  onQuerySubmit,
  onSortChange,
  page = 1,
  photoAlbumHrefBuilder,
  query = '',
  sort,
  titleActionHref,
  totalCount = 0,
  totalPages = 1,
}: any) {
  return (
    <section className={styles.directoryPanel}>
      <header className={styles.panelHeader}>
        <div>
          <h2 className={styles.panelTitle}>사업장 목록</h2>
          <p className={styles.panelHint}>사업장 기준정보를 검색하고 하위 현장으로 바로 이동합니다.</p>
        </div>
        <div className={styles.toolbar}>
          <form className={styles.sectionHeaderSearchShell} onSubmit={(event) => { event.preventDefault(); onQuerySubmit?.(); }}>
            <input className={styles.sectionHeaderSearchInput} value={query} placeholder="사업장명, 사업개시번호, 담당자 검색" onChange={(event) => onQueryChange?.(event.target.value)} />
            <button className={styles.sectionHeaderSearchButton} type="submit" disabled={busy}>검색</button>
          </form>
          <button type="button" className={styles.secondaryButton} onClick={onExportRequest}>내보내기</button>
          <button type="button" className={styles.primaryButton} onClick={onCreateRequest}>사업장 추가</button>
        </div>
      </header>
      <div className={styles.filterBar}>
        <button type="button" className={styles.filterButton} onClick={() => onSortChange?.({ key: 'name', direction: 'asc' })}>이름순</button>
        <button type="button" className={styles.filterButton} onClick={() => onSortChange?.({ key: 'updated_at', direction: 'desc' })}>최근 수정순</button>
        {titleActionHref ? <Link className={styles.secondaryButton} href={titleActionHref}>전체 현장 보기</Link> : null}
      </div>
      {filteredHeadquarters.length > 0 ? (
        <div className={styles.tableWrap}>
          <table className={styles.table}>
            <thead><tr><th>사업장</th><th>번호</th><th>담당자</th><th>상태</th><th>작업</th></tr></thead>
            <tbody>
              {filteredHeadquarters.map((item: SafetyHeadquarter) => (
                <tr key={item.id}>
                  <td><div className={styles.nameStack}><strong className={styles.namePrimary}>{item.name}</strong><span className={styles.nameSecondary}>{item.address || '주소 미입력'}</span></div></td>
                  <td><div className={styles.nameStack}><span>{item.opening_number || '-'}</span><span className={styles.nameSecondary}>{item.business_registration_no || '-'}</span></div></td>
                  <td><div className={styles.nameStack}><span>{item.contact_name || '-'}</span><span className={styles.nameSecondary}>{item.contact_phone || '-'}</span></div></td>
                  <td>{statusBadge(item)}</td>
                  <td><div className={styles.actions}><button type="button" className={styles.textButton} onClick={() => onOpenSitesRequest?.(item)}>현장</button>{photoAlbumHrefBuilder ? <Link className={styles.textButton} href={photoAlbumHrefBuilder(item)}>사진첩</Link> : null}<button type="button" className={styles.textButton} onClick={() => onEditRequest?.(item)}>수정</button><button type="button" className={styles.textButton} onClick={() => onDeleteRequest?.(item)}>삭제</button></div></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : <div className={styles.empty}><strong>표시할 사업장이 없습니다.</strong><span>검색 조건을 조정하거나 사업장을 추가해 주세요.</span></div>}
      <footer className={styles.pagination}><span>{totalCount}개 사업장 · {page}/{Math.max(totalPages, 1)} 페이지</span><div className={styles.actions}><button className={styles.secondaryButton} disabled={page <= 1} onClick={() => onPageChange?.(page - 1)}>이전</button><button className={styles.secondaryButton} disabled={page >= totalPages} onClick={() => onPageChange?.(page + 1)}>다음</button></div></footer>
    </section>
  );
}
