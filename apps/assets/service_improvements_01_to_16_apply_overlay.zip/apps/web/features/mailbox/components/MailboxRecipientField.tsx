'use client';

import type { FocusEvent, KeyboardEvent } from 'react';
import type { MailRecipientSuggestion } from '@/types/mail';

export type MailboxRecipientSuggestionOption = MailRecipientSuggestion;

export function MailboxRecipientField({
  inputValue,
  label = '받는 사람',
  onBlur,
  onChangeInput,
  onFocusInput,
  onInputChange,
  onInputKeyDown,
  onKeyDown,
  onRemoveRecipient,
  onSelectSuggestion,
  recipients,
  suggestionIndex = 0,
  suggestions = [],
  suggestionsLoading = false,
  suggestionsOpen = false,
}: {
  inputValue: string;
  label?: string;
  onBlur?: (event?: FocusEvent<HTMLInputElement>) => void;
  onChangeInput?: (value: string) => void;
  onFocusInput?: () => void;
  onInputChange?: (value: string) => void;
  onInputKeyDown?: (event: KeyboardEvent<HTMLInputElement>) => void;
  onKeyDown?: (event: KeyboardEvent<HTMLInputElement>) => void;
  onRemoveRecipient: (email: string) => void;
  onSelectSuggestion?: (suggestion: MailboxRecipientSuggestionOption) => void;
  recipients: string[];
  suggestionIndex?: number;
  suggestions?: MailboxRecipientSuggestionOption[];
  suggestionsLoading?: boolean;
  suggestionsOpen?: boolean;
}) {
  const handleChange = (value: string) => {
    onChangeInput?.(value);
    onInputChange?.(value);
  };

  const handleKeyDown = (event: KeyboardEvent<HTMLInputElement>) => {
    onKeyDown?.(event);
    onInputKeyDown?.(event);
  };

  return (
    <div className="mailbox-recipient-field" style={{ display: 'grid', gap: 8 }}>
      <div style={{ display: 'grid', gridTemplateColumns: '72px minmax(0, 1fr)', gap: 10, alignItems: 'start' }}>
        <span style={{ color: '#5f6368', fontSize: 13, paddingTop: 9 }}>{label}</span>
        <div
          style={{
            alignItems: 'center',
            border: '1px solid #d2d7e0',
            borderRadius: 12,
            display: 'flex',
            flexWrap: 'wrap',
            gap: 6,
            minHeight: 42,
            padding: '6px 10px',
            background: '#fff',
          }}
        >
          {recipients.map((recipient) => (
            <button
              key={recipient}
              type="button"
              onClick={() => onRemoveRecipient(recipient)}
              aria-label={`${recipient} 삭제`}
              style={{
                alignItems: 'center',
                background: '#eef3fd',
                border: '1px solid #d7e2fb',
                borderRadius: 999,
                color: '#0b57d0',
                cursor: 'pointer',
                display: 'inline-flex',
                fontSize: 12,
                fontWeight: 700,
                gap: 6,
                minHeight: 28,
                padding: '0 10px',
              }}
            >
              <span>{recipient}</span>
              <span aria-hidden>×</span>
            </button>
          ))}
          <input
            value={inputValue}
            placeholder={recipients.length > 0 ? '' : '이메일 주소 입력'}
            onChange={(event) => handleChange(event.target.value)}
            onKeyDown={handleKeyDown}
            onFocus={onFocusInput}
            onBlur={(event) => {
              // Give suggestion buttons a moment to receive click events.
              window.setTimeout(() => onBlur?.(event), 120);
            }}
            style={{
              border: 0,
              flex: '1 1 180px',
              minHeight: 30,
              minWidth: 160,
              outline: 'none',
            }}
          />
        </div>
      </div>

      {suggestionsOpen ? (
        <div
          role="listbox"
          aria-label="수신자 추천"
          style={{
            background: '#fff',
            border: '1px solid #d2d7e0',
            borderRadius: 14,
            boxShadow: '0 8px 24px rgba(60,64,67,.16)',
            display: 'grid',
            gap: 2,
            marginLeft: 82,
            maxHeight: 220,
            overflow: 'auto',
            padding: 6,
          }}
        >
          {suggestionsLoading ? (
            <div style={{ color: '#5f6368', fontSize: 13, padding: 10 }}>추천 주소를 불러오는 중입니다.</div>
          ) : suggestions.length > 0 ? (
            suggestions.map((suggestion, index) => (
              <button
                key={suggestion.email}
                type="button"
                role="option"
                aria-selected={index === suggestionIndex}
                onMouseDown={(event) => event.preventDefault()}
                onClick={() => onSelectSuggestion?.(suggestion)}
                style={{
                  background: index === suggestionIndex ? '#edf2fa' : 'transparent',
                  border: 0,
                  borderRadius: 10,
                  cursor: 'pointer',
                  display: 'grid',
                  gap: 2,
                  padding: '9px 10px',
                  textAlign: 'left',
                }}
              >
                <strong>{suggestion.name || suggestion.email}</strong>
                {suggestion.name ? <span style={{ color: '#5f6368', fontSize: 12 }}>{suggestion.email}</span> : null}
              </button>
            ))
          ) : inputValue.trim() ? (
            <div style={{ color: '#5f6368', fontSize: 13, padding: 10 }}>추천 주소가 없습니다. Enter로 직접 추가할 수 있습니다.</div>
          ) : null}
        </div>
      ) : null}
    </div>
  );
}

export default MailboxRecipientField;
