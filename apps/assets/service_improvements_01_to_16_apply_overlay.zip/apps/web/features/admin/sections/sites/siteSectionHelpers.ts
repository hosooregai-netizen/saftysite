import type { SafetySite } from '@/types/backend';
import type { SafetySiteInput } from '@/types/controller';

export type SiteAssignmentFilter = 'all' | 'assigned' | 'unassigned' | string;

export interface SiteFormState {
  headquarter_id: string;
  site_name: string;
  client_business_name: string;
  site_address: string;
  manager_name: string;
  status: string;
  management_number: string;
  memo: string;
  [key: string]: string;
}

export const EMPTY_FORM: SiteFormState = {
  headquarter_id: '',
  site_name: '',
  client_business_name: '',
  site_address: '',
  manager_name: '',
  status: 'active',
  management_number: '',
  memo: '',
};

export function isCreateReady(form: SiteFormState, lockedHeadquarterId?: string | null) {
  return Boolean((form.headquarter_id || lockedHeadquarterId) && form.site_name.trim());
}

export function buildSitePayload(form: SiteFormState, lockedHeadquarterId?: string | null): SafetySiteInput {
  return {
    ...form,
    headquarter_id: form.headquarter_id || lockedHeadquarterId || '',
  };
}

export function buildSiteSortComparator(sort: { key?: string; direction?: 'asc' | 'desc' } | string) {
  const key = typeof sort === 'string' ? sort : sort.key || 'last_visit_date';
  const multiplier = typeof sort === 'object' && sort.direction === 'asc' ? 1 : -1;
  return (left: SafetySite, right: SafetySite) => {
    if (key === 'name' || key === 'site_name') {
      return left.site_name.localeCompare(right.site_name, 'ko') * (multiplier === 1 ? 1 : -1);
    }
    return String(right.last_visit_date || '').localeCompare(String(left.last_visit_date || '')) * (multiplier === -1 ? 1 : -1);
  };
}
