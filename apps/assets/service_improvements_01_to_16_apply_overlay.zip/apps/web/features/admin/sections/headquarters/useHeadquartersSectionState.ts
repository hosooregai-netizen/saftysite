'use client';

import { useState } from 'react';

export interface HeadquarterFormState {
  address: string;
  business_registration_no: string;
  contact_name: string;
  contact_phone: string;
  corporate_registration_no: string;
  is_active: boolean;
  license_no: string;
  management_number: string;
  memo: string;
  name: string;
  opening_number: string;
}

export const EMPTY_HEADQUARTER_FORM: HeadquarterFormState = {
  address: '',
  business_registration_no: '',
  contact_name: '',
  contact_phone: '',
  corporate_registration_no: '',
  is_active: true,
  license_no: '',
  management_number: '',
  memo: '',
  name: '',
  opening_number: '',
};

export function useHeadquartersSectionState(initialOpen = false) {
  const [isOpen, setIsOpen] = useState(initialOpen);
  const [form, setForm] = useState<HeadquarterFormState>(EMPTY_HEADQUARTER_FORM);
  const [editingId, setEditingId] = useState<string | null>(null);

  return {
    closeModal: () => setIsOpen(false),
    editingId,
    form,
    isOpen,
    openCreateModal: () => {
      setEditingId(null);
      setForm(EMPTY_HEADQUARTER_FORM);
      setIsOpen(true);
    },
    openEditModal: (input: Partial<HeadquarterFormState> & { id?: string }) => {
      setEditingId(input.id ?? null);
      setForm({ ...EMPTY_HEADQUARTER_FORM, ...input });
      setIsOpen(true);
    },
    setEditingId,
    setForm,
    setIsOpen,
  };
}
