export function saveBlobAsFile(blob: Blob, filename: string) {
  if (typeof window === 'undefined') return;
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = filename || 'download';
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  URL.revokeObjectURL(url);
}

export async function fetchInspectionPdfDocument(input: unknown): Promise<Blob> {
  const response = await fetch('/api/documents/inspection/pdf', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(input ?? {}),
  });
  if (!response.ok) throw new Error('PDF 문서를 생성하지 못했습니다.');
  return response.blob();
}

export async function fetchInspectionHwpxDocument(input: unknown): Promise<Blob> {
  const response = await fetch('/api/documents/inspection/hwpx', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(input ?? {}),
  });
  if (!response.ok) throw new Error('HWPX 문서를 생성하지 못했습니다.');
  return response.blob();
}
