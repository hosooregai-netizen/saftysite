export async function convertHwpxBufferToPdf(_buffer: Uint8Array): Promise<Uint8Array> {
  return new TextEncoder().encode('%PDF-1.4\n% placeholder PDF\n%%EOF');
}
