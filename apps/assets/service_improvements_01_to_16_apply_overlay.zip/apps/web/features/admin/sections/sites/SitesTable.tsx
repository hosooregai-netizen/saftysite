'use client';

import styles from '@/features/admin/sections/AdminSectionShared.module.css';
import type { SafetySite } from '@/types/backend';

function siteStatusLabel(status: string | undefined) {
  if (status === 'paused') return '중지';
  if (status === 'completed') return '완료';
  if (status === 'archived') return '보관';
  return '진행 중';
}

export function SitesTable({
  busy,
  canDelete,
  hasCustomEntry,
  onDeleteSite,
  onDownloadBasicMaterial,
  onOpenAssignmentModal,
  onOpenEdit,
  onOpenSiteEntry,
  onPageChange,
  onSortChange,
  page = 1,
  sites = [],
  sort,
  totalCount = 0,
  totalPages = 1,
}: any) {
  return (
    <section className={styles.directoryPanel}>
      <header className={styles.panelHeader}>
        <div><h2 className={styles.panelTitle}>현장 목록</h2><p className={styles.panelHint}>배정 현장, 최근 지도일, 보고서/사진첩 진입점을 확인합니다.</p></div>
        <div className={styles.toolbar}>
          <button type="button" className={styles.secondaryButton} onClick={() => onSortChange?.({ key: 'name', direction: 'asc' })}>이름순</button>
          <button type="button" className={styles.secondaryButton} onClick={() => onSortChange?.({ key: 'last_visit_date', direction: 'desc' })}>최근 지도순</button>
          <button type="button" className={styles.secondaryButton} onClick={onOpenAssignmentModal}>배정 관리</button>
        </div>
      </header>
      {sites.length > 0 ? (
        <div className={styles.tableWrap}>
          <table className={styles.table}>
            <thead><tr><th>현장</th><th>사업장</th><th>담당자</th><th>최근 지도</th><th>상태</th><th>작업</th></tr></thead>
            <tbody>
              {sites.map((site: SafetySite) => (
                <tr key={site.id}>
                  <td><div className={styles.nameStack}><strong className={styles.namePrimary}>{site.site_name}</strong><span className={styles.nameSecondary}>{site.site_address || '주소 미입력'}</span></div></td>
                  <td>{site.client_business_name || site.headquarter_detail?.name || '-'}</td>
                  <td>{site.manager_name || '-'}</td>
                  <td>{site.last_visit_date || '-'}</td>
                  <td><span className={`${styles.badge} ${site.status === 'active' || !site.status ? styles.badgeSuccess : styles.badgeMuted}`}>{siteStatusLabel(site.status)}</span></td>
                  <td><div className={styles.actions}><button type="button" className={styles.textButton} onClick={() => onOpenSiteEntry?.(site)}>열기</button><button type="button" className={styles.textButton} onClick={() => onOpenEdit?.(site)}>수정</button><button type="button" className={styles.textButton} onClick={() => onDownloadBasicMaterial?.(site)}>기초자료</button>{canDelete ? <button type="button" className={styles.textButton} onClick={() => onDeleteSite?.(site)}>삭제</button> : null}</div></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : <div className={styles.empty}><strong>표시할 현장이 없습니다.</strong><span>{hasCustomEntry ? '검색 조건을 조정하거나 새 현장을 추가해 주세요.' : '배정된 현장이 없습니다.'}</span></div>}
      <footer className={styles.pagination}><span>{totalCount}개 현장 · {page}/{Math.max(totalPages, 1)} 페이지</span><div className={styles.actions}><button className={styles.secondaryButton} disabled={page <= 1} onClick={() => onPageChange?.(page - 1)}>이전</button><button className={styles.secondaryButton} disabled={page >= totalPages} onClick={() => onPageChange?.(page + 1)}>다음</button></div></footer>
    </section>
  );
}
