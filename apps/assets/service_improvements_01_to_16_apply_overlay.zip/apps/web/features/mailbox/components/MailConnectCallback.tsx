'use client';

import { useEffect } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { completeGoogleMailConnect } from '@/lib/mail/apiClient';
import { clearPendingGoogleMailConnect } from '@/lib/sessionAuthFlow';

const NOTICE_KEY = 'mailbox-oauth-notice';
const ERROR_KEY = 'mailbox-oauth-error';

export default function MailConnectCallback({ provider = 'google' }: { provider?: string }) {
  const router = useRouter();
  const searchParams = useSearchParams();

  useEffect(() => {
    let cancelled = false;

    async function complete() {
      const error = searchParams.get('error');
      const code = searchParams.get('code') || '';
      const state = searchParams.get('state') || '';
      const redirectUri = typeof window === 'undefined' ? '' : `${window.location.origin}/mail/connect/${provider}`;

      try {
        if (error) {
          throw new Error(error);
        }
        if (!code || !state) {
          throw new Error('메일 연결에 필요한 code/state가 없습니다.');
        }
        if (provider !== 'google') {
          throw new Error(`${provider} 메일 연결은 아직 준비 중입니다.`);
        }
        await completeGoogleMailConnect({ authCode: code, redirectUri, state });
        if (typeof window !== 'undefined') {
          window.sessionStorage.setItem(NOTICE_KEY, '구글 메일 계정을 연결했습니다.');
        }
        clearPendingGoogleMailConnect();
        if (!cancelled) router.replace('/mailbox?oauthNotice=구글%20메일%20계정을%20연결했습니다.');
      } catch (nextError) {
        const message = nextError instanceof Error ? nextError.message : '메일 계정 연결에 실패했습니다.';
        if (typeof window !== 'undefined') {
          window.sessionStorage.setItem(ERROR_KEY, message);
        }
        if (!cancelled) router.replace(`/mailbox?oauthError=${encodeURIComponent(message)}`);
      }
    }

    void complete();
    return () => {
      cancelled = true;
    };
  }, [provider, router, searchParams]);

  return (
    <main className="erp-page">
      <section className="erp-panel">
        <h1 className="page-title">메일 계정을 연결하는 중입니다.</h1>
        <p className="page-meta-line">잠시만 기다려 주세요.</p>
      </section>
    </main>
  );
}
