'use client';

import type { ReactNode } from 'react';

export default function AppModal({
  actions,
  children,
  onClose,
  open,
  title,
}: {
  actions?: ReactNode;
  children?: ReactNode;
  onClose: () => void;
  open: boolean;
  title?: string;
}) {
  if (!open) return null;
  return (
    <div role="dialog" aria-modal="true" aria-label={title || '대화상자'} className="app-modal-backdrop">
      <div className="app-modal-card">
        <div className="app-modal-header">
          <h2>{title}</h2>
          <button type="button" className="app-button app-button-secondary" onClick={onClose} aria-label="닫기">
            ×
          </button>
        </div>
        <div className="app-modal-body">{children}</div>
        {actions ? <div className="app-modal-actions">{actions}</div> : null}
      </div>
    </div>
  );
}
