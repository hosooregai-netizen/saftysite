'use client';

import AppModal from '@/components/ui/AppModal';
import styles from '@/features/admin/sections/AdminSectionShared.module.css';
import type { SiteFormState } from '@/features/admin/sections/sites/siteSectionHelpers';

export function SiteEditorModal({
  busy,
  editingId,
  form,
  headquarters,
  isCreateReady,
  lockedHeadquarterId,
  onClose,
  onCreateHeadquarter,
  onSubmit,
  setForm,
}: {
  busy?: boolean;
  editingId?: string | null;
  form: SiteFormState;
  headquarters: Array<{ id: string; name: string }>;
  isCreateReady?: boolean;
  lockedHeadquarterId?: string | null;
  onClose: () => void;
  onCreateHeadquarter?: () => void;
  onSubmit: (value: SiteFormState) => void | Promise<void>;
  setForm: (value: SiteFormState) => void;
}) {
  const patch = (key: keyof SiteFormState, value: string) => setForm({ ...form, [key]: value });
  const open = Boolean(editingId);
  return (
    <AppModal open={open} title={editingId === 'create' ? '현장 추가' : '현장 수정'} onClose={onClose}>
      <div className={styles.modalGrid}>
        <div className={styles.formGrid}>
          <label className={styles.formField}>
            <span>사업장 *</span>
            <select value={form.headquarter_id || lockedHeadquarterId || ''} disabled={Boolean(lockedHeadquarterId)} onChange={(event) => patch('headquarter_id', event.target.value)}>
              <option value="">사업장 선택</option>
              {headquarters.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}
            </select>
          </label>
          <label className={styles.formField}><span>현장명 *</span><input value={form.site_name} onChange={(event) => patch('site_name', event.target.value)} /></label>
          <label className={styles.formField}><span>고객/사업장명</span><input value={form.client_business_name} onChange={(event) => patch('client_business_name', event.target.value)} /></label>
          <label className={styles.formField}><span>담당자</span><input value={form.manager_name} onChange={(event) => patch('manager_name', event.target.value)} /></label>
          <label className={styles.formField}><span>사업장관리번호</span><input value={form.management_number} onChange={(event) => patch('management_number', event.target.value)} /></label>
          <label className={styles.formField}>
            <span>상태</span>
            <select value={form.status} onChange={(event) => patch('status', event.target.value)}>
              <option value="active">진행 중</option>
              <option value="paused">중지</option>
              <option value="completed">완료</option>
              <option value="archived">보관</option>
            </select>
          </label>
        </div>
        <label className={styles.formField}><span>현장 주소</span><input value={form.site_address} onChange={(event) => patch('site_address', event.target.value)} /></label>
        <label className={styles.formField}><span>메모</span><textarea rows={3} value={form.memo} onChange={(event) => patch('memo', event.target.value)} /></label>
        <div className={styles.actions}>
          {onCreateHeadquarter ? <button type="button" className={styles.secondaryButton} onClick={onCreateHeadquarter}>사업장 먼저 추가</button> : null}
          <span style={{ flex: 1 }} />
          <button type="button" className={styles.secondaryButton} onClick={onClose}>취소</button>
          <button type="button" className={styles.primaryButton} disabled={busy || !isCreateReady} onClick={() => void onSubmit(form)}>저장</button>
        </div>
      </div>
    </AppModal>
  );
}
