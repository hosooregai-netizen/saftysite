
'use client';

export default function ReportExportGatePanel({
  blockingIssues,
  canExport,
  exportBlockedReason,
  onOpenReviewQueue,
  onToggleResponsibility,
  responsibilityConfirmed,
  requiredCount,
  totalOpenCount,
}: {
  blockingIssues: string[];
  canExport: boolean;
  exportBlockedReason: string;
  onOpenReviewQueue: () => void;
  onToggleResponsibility: (value: boolean) => void;
  responsibilityConfirmed: boolean;
  requiredCount: number;
  totalOpenCount: number;
}) {
  const tone = canExport ? 'ready' : requiredCount > 0 || blockingIssues.length > 0 ? 'blocked' : 'pending';
  return (
    <section
      aria-label="출력 가능 상태"
      style={{
        border: tone === 'ready' ? '1px solid rgba(34, 112, 75, .24)' : '1px solid rgba(185, 122, 42, .28)',
        borderRadius: 18,
        background: tone === 'ready'
          ? 'linear-gradient(180deg, #f0fbf5 0%, #fbfffd 100%)'
          : 'linear-gradient(180deg, #fff8ec 0%, #fffef9 100%)',
        display: 'grid',
        gap: 14,
        padding: 16,
      }}
    >
      <div style={{ display: 'flex', gap: 12, justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap' }}>
        <div style={{ display: 'grid', gap: 4 }}>
          <strong style={{ color: tone === 'ready' ? '#16794d' : '#8f6414' }}>
            {canExport ? '출력 준비가 완료되었습니다.' : '출력 전 확인이 필요합니다.'}
          </strong>
          <span style={{ color: '#5f6368', lineHeight: 1.6 }}>
            {canExport
              ? 'PDF/HWPX 출력과 크레딧 차감 단계로 진행할 수 있습니다.'
              : exportBlockedReason || '검토 항목과 책임 확인 상태를 확인해 주세요.'}
          </span>
        </div>
        <button type="button" className="erp-button erp-button-secondary" onClick={onOpenReviewQueue}>
          검토 항목 열기
        </button>
      </div>

      <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
        <span className="status-chip">열린 항목 {totalOpenCount}</span>
        <span className="status-chip">필수 {requiredCount}</span>
        <span className="status-chip">차단 이슈 {blockingIssues.length}</span>
        <span className="status-chip">책임 확인 {responsibilityConfirmed ? '완료' : '필요'}</span>
      </div>

      {blockingIssues.length > 0 ? (
        <div style={{ display: 'grid', gap: 6 }}>
          <strong>출력 전 차단 이슈</strong>
          <ul style={{ margin: 0, paddingLeft: 18 }}>
            {blockingIssues.slice(0, 5).map((issue) => <li key={issue}>{issue}</li>)}
          </ul>
        </div>
      ) : null}

      <label style={{ alignItems: 'flex-start', display: 'flex', gap: 10, lineHeight: 1.6 }}>
        <input
          checked={responsibilityConfirmed}
          onChange={(event) => onToggleResponsibility(event.target.checked)}
          style={{ marginTop: 4 }}
          type="checkbox"
        />
        <span>
          AI 초안과 사진, 위험요인, 개선대책, 법적 근거 후보를 검토했으며 출력 후 책임이 작성자에게 있음을 확인합니다.
        </span>
      </label>
    </section>
  );
}
