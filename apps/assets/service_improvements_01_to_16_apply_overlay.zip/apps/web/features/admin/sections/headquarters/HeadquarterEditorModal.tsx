'use client';

import AppModal from '@/components/ui/AppModal';
import styles from '@/features/admin/sections/AdminSectionShared.module.css';
import type { HeadquarterFormState } from '@/features/admin/sections/headquarters/useHeadquartersSectionState';

export function HeadquarterEditorModal({
  busy,
  canSubmit,
  editingId,
  form,
  onClose,
  onFormChange,
  onSubmit,
  open,
}: {
  busy?: boolean;
  canSubmit?: boolean;
  editingId?: string | null;
  form: HeadquarterFormState;
  onClose: () => void;
  onFormChange: (value: HeadquarterFormState) => void;
  onSubmit: (value: HeadquarterFormState) => void | Promise<void>;
  open: boolean;
}) {
  const patch = (key: keyof HeadquarterFormState, value: string | boolean) => onFormChange({ ...form, [key]: value });
  return (
    <AppModal open={open} title={editingId ? '사업장 수정' : '사업장 추가'} onClose={onClose}>
      <div className={styles.modalGrid}>
        <div className={styles.formGrid}>
          <label className={styles.formField}><span>사업장명 *</span><input value={form.name} onChange={(event) => patch('name', event.target.value)} /></label>
          <label className={styles.formField}><span>사업개시번호</span><input value={form.opening_number} onChange={(event) => patch('opening_number', event.target.value)} /></label>
          <label className={styles.formField}><span>사업자등록번호</span><input value={form.business_registration_no} onChange={(event) => patch('business_registration_no', event.target.value)} /></label>
          <label className={styles.formField}><span>법인등록번호</span><input value={form.corporate_registration_no} onChange={(event) => patch('corporate_registration_no', event.target.value)} /></label>
          <label className={styles.formField}><span>담당자</span><input value={form.contact_name} onChange={(event) => patch('contact_name', event.target.value)} /></label>
          <label className={styles.formField}><span>연락처</span><input value={form.contact_phone} onChange={(event) => patch('contact_phone', event.target.value)} /></label>
          <label className={styles.formField}><span>면허번호</span><input value={form.license_no} onChange={(event) => patch('license_no', event.target.value)} /></label>
          <label className={styles.formField}><span>관리번호</span><input value={form.management_number} onChange={(event) => patch('management_number', event.target.value)} /></label>
        </div>
        <label className={styles.formField}><span>주소</span><input value={form.address} onChange={(event) => patch('address', event.target.value)} /></label>
        <label className={styles.formField}><span>메모</span><textarea rows={3} value={form.memo} onChange={(event) => patch('memo', event.target.value)} /></label>
        <label className={styles.formField} style={{ display: 'flex', alignItems: 'center', gap: 8 }}><input type="checkbox" checked={form.is_active} onChange={(event) => patch('is_active', event.target.checked)} /> 활성 사업장</label>
        <div className={styles.actions}>
          <button type="button" className={styles.secondaryButton} onClick={onClose}>취소</button>
          <button type="button" className={styles.primaryButton} disabled={busy || !canSubmit} onClick={() => void onSubmit(form)}>저장</button>
        </div>
      </div>
    </AppModal>
  );
}
