'use client';

import styles from '@/features/admin/sections/AdminSectionShared.module.css';
import type { SafetySite } from '@/types/backend';
import type { SafetyHeadquarter } from '@/types/controller';

export function HeadquarterSummaryPanel({ headquarter, onEdit, onOpenAssignment, sites = [] }: { headquarter: SafetyHeadquarter; onEdit?: () => void; onOpenAssignment?: () => void; sites?: SafetySite[] }) {
  const activeSites = sites.filter((site) => site.status !== 'archived' && site.status !== 'completed').length;
  return (
    <section className={styles.detailCard}>
      <div className={styles.panelHeader} style={{ padding: 0, border: 0 }}>
        <div><h2 className={styles.panelTitle}>{headquarter.name}</h2><p className={styles.panelHint}>{headquarter.address || '주소 미입력'}</p></div>
        <div className={styles.actions}><button className={styles.secondaryButton} onClick={onEdit}>수정</button><button className={styles.secondaryButton} onClick={onOpenAssignment}>배정</button></div>
      </div>
      <div className={styles.summaryGrid}>
        <div className={styles.summaryCard}><div className={styles.summaryValue}>{sites.length}</div><div className={styles.summaryLabel}>전체 현장</div></div>
        <div className={styles.summaryCard}><div className={styles.summaryValue}>{activeSites}</div><div className={styles.summaryLabel}>진행 현장</div></div>
        <div className={styles.summaryCard}><div className={styles.summaryValue}>{headquarter.is_active === false ? '비활성' : '활성'}</div><div className={styles.summaryLabel}>사업장 상태</div></div>
      </div>
      <div className={styles.detailGrid}>
        <div className={styles.detailField}><span className={styles.fieldLabel}>사업개시번호</span><span className={styles.fieldValue}>{headquarter.opening_number || '-'}</span></div>
        <div className={styles.detailField}><span className={styles.fieldLabel}>사업자등록번호</span><span className={styles.fieldValue}>{headquarter.business_registration_no || '-'}</span></div>
        <div className={styles.detailField}><span className={styles.fieldLabel}>담당자</span><span className={styles.fieldValue}>{headquarter.contact_name || '-'}</span></div>
        <div className={styles.detailField}><span className={styles.fieldLabel}>연락처</span><span className={styles.fieldValue}>{headquarter.contact_phone || '-'}</span></div>
      </div>
    </section>
  );
}
